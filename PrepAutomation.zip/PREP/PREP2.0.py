import pandas as pd
import datetime

# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers.xlsx')
mid_df = pd.read_excel('Used MIDs.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= '03-27-2023')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '03-27-2023')
habib_df = pd.read_excel('Habib.xlsx', sheet_name= '03-27-2023')



nextgen_duplicate_df = pd.DataFrame()
mitti_duplicate_df = pd.DataFrame()
habib_duplicate_df = pd.DataFrame()



now = datetime.datetime.now()


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 10] = nextgen_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 11] = nextgen_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 12] = nextgen_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

nextgen_df['DOB'] = pd.to_datetime(nextgen_df['DOB']).dt.strftime('%m/%d/%Y')


duplicates_nextgen = nextgen_df[nextgen_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not duplicates_nextgen.empty:
    for _, row in duplicates_nextgen.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_nextgen)
    nextgen_df = nextgen_df.drop_duplicates(subset=[7], keep="first")
else:
    print("No Duplicates Found!")
#to do: check to make sure duplicate are the same people, if so then delete, if not reject both.
nextgen_dups = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])

for index1, phonecol in nextgen_df.iterrows():
    for index2, phonecol2 in dnc_df.iterrows():
        if phonecol['Phone (Billing)'] == phonecol2['phone']:
            nextgen_df = nextgen_df.drop(index=index1)
            nextgen_dups = nextgen_dups.append(nextgen_df.loc[index1])
            print(f"Match found: row {index1+1} in file1.xlsx and row {index2+1} in file2.xlsx")

for index1, midcol in nextgen_df.iterrows():
    for index2, midcol2 in mid_df.iterrows():
        if midcol['MedicareNumber'] == midcol2['MEDICARENUMBER']:
            nextgen_df = nextgen_df.drop(index=index1)
            nextgen_dups = nextgen_dups.append(nextgen_df.loc[index1])
            print(f"Match found: row {index1+1} in file1.xlsx and row {index2+1} in file2.xlsx")

orderbatch = pd.DataFrame(columns=['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB', 'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source'])
orderbatch['Order Status'] = "In Process"
orderbatch['Order Number'] = 40000000
orderbatch['Order Number'] = orderbatch['Order Number'].apply(lambda x: x + 1)
orderbatch = orderbatch.append(nextgen_df, ignore_index = True)
orderbatch.to_excel('OrderBatch.xlsx', index=False, header = True)
orderbatch = pd.read_excel('OrderBatch.xlsx')
nextgen_dups.to_excel('NextGen Completed.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-End-------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#












#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



habib_df.iloc[:, 3] = habib_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 4] = habib_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 5] = habib_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 6] = habib_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 7] = habib_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 8] = habib_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
habib_df.iloc[:, 9] = habib_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 10] = habib_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 11] = habib_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 12] = habib_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

habib_df['DOB'] = pd.to_datetime(habib_df['DOB']).dt.strftime('%m/%d/%Y')


duplicates_habib = habib_df[habib_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not duplicates_habib.empty:
    for _, row in duplicates_habib.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        habib_duplicate_df = habib_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_habib)
    habib_df = habib_df.drop_duplicates(subset=[7], keep="first")
else:
    print("No Duplicates Found!")
#to do: check to make sure duplicate are the same people, if so then delete, if not reject both.
habib_dups = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])

for index1, phonecol in habib_df.iterrows():
    for index2, phonecol2 in dnc_df.iterrows():
        if phonecol['Phone (Billing)'] == phonecol2['phone']:
            habib_df = habib_df.drop(index=index1)
            habib_dups = habib_dups.append(habib_df.loc[index1])
            print(f"Match found: row {index1+1} in Habib.xlsx and row {index2+1} in DNC.xlsx")

for index1, midcol in habib_df.iterrows():
    for index2, midcol2 in mid_df.iterrows():
        if midcol['MedicareNumber'] == midcol2['MEDICARENUMBER']:
            habib_df = habib_df.drop(index=index1)
            habib_dups = habib_dups.append(habib_df.loc[index1])
            print(f"Match found: row {index1+1} in Habib.xlsx and row {index2+1} in MID.xlsx")

for index1, ordercol in habib_df.iterrows():
    for index2, ordercol2 in orderbatch.iterrows():
        if ordercol['MedicareNumber'] == ordercol2['MEDICARENUMBER']:
            habib_df = nextgen_df.drop(index=index1)
            habib_dups = habib_dups.append(habib_df.loc[index1])
            print(f"Match found: row {index1+1} in Habib.xlsx and row {index2+1} in MID.xlsx")

orderbatch['Order Status'] = "In Process"
orderbatch['Order Number'] = orderbatch['Order Number'].apply(lambda x: x + 1)
orderbatch = orderbatch.append(habib_df, ignore_index = True)
orderbatch.to_excel('OrderBatch.xlsx', index=False, header = True)
orderbatch = pd.read_excel('OrderBatch.xlsx')
habib_dups.to_excel('Habib Completed.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#















#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------MITTI-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



mitti_df.iloc[:, 3] = mitti_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 4] = mitti_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 5] = mitti_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 6] = mitti_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 7] = mitti_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 8] = mitti_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
mitti_df.iloc[:, 9] = mitti_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 10] = mitti_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 11] = mitti_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 12] = mitti_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

mitti_df['DOB'] = pd.to_datetime(mitti_df['DOB']).dt.strftime('%m/%d/%Y')


duplicates_mitti = mitti_df[mitti_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not duplicates_mitti.empty:
    for _, row in duplicates_mitti.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        mitti_duplicate_df = mitti_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_mitti)
    mitti_df = mitti_df.drop_duplicates(subset=[7], keep="first")
else:
    print("No Duplicates Found!")
#to do: check to make sure duplicate are the same people, if so then delete, if not reject both.
mitti_dups = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])

for index1, phonecol in mitti_df.iterrows():
    for index2, phonecol2 in dnc_df.iterrows():
        if phonecol['Phone (Billing)'] == phonecol2['phone']:
            mitti_df = mitti_df.drop(index=index1)
            mitti_dups = mitti_dups.append(mitti_df.loc[index1])
            print(f"Match found: row {index1+1} in Habib.xlsx and row {index2+1} in DNC.xlsx")

for index1, midcol in mitti_df.iterrows():
    for index2, midcol2 in mid_df.iterrows():
        if midcol['MedicareNumber'] == midcol2['MEDICARENUMBER']:
            mitti_df = mitti_df.drop(index=index1)
            mitti_dups = mitti_dups.append(mitti_df.loc[index1])
            print(f"Match found: row {index1+1} in Habib.xlsx and row {index2+1} in MID.xlsx")

for index1, ordercol in mitti_df.iterrows():
    for index2, ordercol2 in orderbatch.iterrows():
        if ordercol['MedicareNumber'] == ordercol2['MEDICARENUMBER']:
            mitti_df = mitti_df.drop(index=index1)
            mitti_dups = mitti_dups.append(mitti_df.loc[index1])
            print(f"Match found: row {index1+1} in Habib.xlsx and row {index2+1} in MID.xlsx")

orderbatch['Order Status'] = "In Process"
orderbatch['Order Number'] = orderbatch['Order Number'].apply(lambda x: x + 1)
orderbatch = orderbatch.append(mitti_df, ignore_index = True)
orderbatch.to_excel('OrderBatch.xlsx', index=False, header = True)
orderbatch = pd.read_excel('OrderBatch.xlsx')
mitti_dups.to_excel('Mitti Completed.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------MITTI-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
