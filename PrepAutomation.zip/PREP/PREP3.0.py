import pandas as pd
import datetime
import re
import openpyxl
import shutil


shutil.os.makedirs("C:\\AlphaData\\PREP\\March\\30")
# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers 0330.xlsx')
mid_df = pd.read_excel('Used MIDs 0330.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= '03-30-2023')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '03-30-2023')
habib_df = pd.read_excel('Habib.xlsx', sheet_name= '03-30-2023')
#cpl_df = pd.read_excel('CPL.xlsx', sheet_name= '03-29-2023')
seventel_df = pd.read_excel('7Tel.xlsx', sheet_name= '03-30-2023')
p1_df = pd.read_excel('P1.xlsx', sheet_name= '03-30-2023')
#bluebells_df = pd.read_excel('BlueBells.xlsx', sheet_name= '03-29-2023')
#amisgos_df = pd.read_excel('Amigos.xlsx', sheet_name= '')
#telemax_df = pd.read_excel('Telemax.xlsx', sheet_name= '')


nextgen_raw = nextgen_df.copy()
#cpl_raw = cpl_df.copy()
habib_raw = habib_df.copy()
mitti_raw = mitti_df.copy()
#bluebells_raw = bluebells_df.copy()
seventel_raw = seventel_df.copy()
#amigos_raw = amigos_df.copy()
p1_raw = p1_df.copy()
#telemax_raw = telemax_df.copy()



now = datetime.datetime.now()


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

nextgen_dups = pd.DataFrame()

nextgen_raw['Source'] = "NextGen"
nextgen_raw['Order Status'] = "InProcess"
nextgen_raw['Order Date'] = '03-30-2023'
nextgen_raw['Alpha Status'] = "Accepted"
nextgen_raw['Error'] = ""


def clean_string(s):
    s = str(s)
    s = re.sub(r'[^\w\s]', '', s)  # remove all characters except for letters, digits, and whitespace
    s = re.sub(r'[\n]', '', s)  # remove newlines
    return s.strip()

def clean_row(row):
    cleaned_row = [clean_string(value) for value in row]
    comment = ', '.join(f"replace '{old}' with '{new}'" for old, new in zip(row, cleaned_row) if old != new)
    if not comment:
        comment = ''
    return cleaned_row, comment

# Apply the clean_row function to each row of the specified columns
columns_to_clean = [3,4,5,7,8,9,10]
cleaned_df = nextgen_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
nextgen_cleaned_df = nextgen_df.copy()

# Assign the 'comment' column to the new dataframe
nextgen_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
nextgen_raw['Alpha Comment'] = cleaned_df['Alpha Comment']


nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 10] = nextgen_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 11] = nextgen_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 12] = nextgen_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)

nextgen_raw.iloc[:, 3] = nextgen_raw.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 4] = nextgen_raw.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 5] = nextgen_raw.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 6] = nextgen_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 7] = nextgen_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 8] = nextgen_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
nextgen_raw.iloc[:, 9] = nextgen_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 10] = nextgen_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 11] = nextgen_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 12] = nextgen_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)



nextgen_df['DOB'] = pd.to_datetime(nextgen_df['DOB']).dt.strftime('%m/%d/%Y')
nextgen_raw['DOB'] = pd.to_datetime(nextgen_raw['DOB']).dt.strftime('%m/%d/%Y')


# Merge the cleaned columns back into the original dataframe

nextgen_dups = nextgen_df[nextgen_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not nextgen_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=nextgen_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in nextgen_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            nextgen_df = nextgen_df.drop(group.index[1:])
            nextgen_raw.loc[nextgen_dups.index,'Source'] = "NextGen"
            nextgen_raw.loc[nextgen_dups.index,'Error'] = "Duplicate Medicare ID"
            nextgen_raw.loc[nextgen_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            nextgen_df = nextgen_df.drop(group.index)
            nextgen_raw.loc[nextgen_dups.index,'Source'] = "NextGen"
            nextgen_raw.loc[nextgen_dups.index,'Error'] = "Duplicate Medicare ID"
            nextgen_raw.loc[nextgen_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    nextgen_df = pd.concat([nextgen_df, unique_records])
    nextgen_raw = pd.concat([nextgen_raw, unique_records])


nextgen_mid_matches = nextgen_df[nextgen_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not nextgen_mid_matches.empty:
    nextgen_raw.loc[nextgen_mid_matches.index, 'Alpha Status'] = "Rejected"
    nextgen_raw.loc[nextgen_mid_matches.index, 'Error'] = "Medicare Number matched with MID List"
    print("Found phone matches in NextGen and MID List.")
    nextgen_df = nextgen_df.drop(nextgen_mid_matches.index)


nextgen_df['Phone (Billing)'] = nextgen_df['Phone (Billing)'].astype(str)
nextgen_phone_matches = nextgen_df[nextgen_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not nextgen_phone_matches.empty:
    nextgen_raw.loc[nextgen_phone_matches.index, 'Alpha Status'] = "Rejected"
    nextgen_raw.loc[nextgen_phone_matches.index, 'Alpha Status'] = "Phone Number matched with DNC List"
    print("Found phone matches in NextGen and DNC List.")
    nextgen_df = nextgen_df.drop(nextgen_phone_matches.index)



orderbatch_df = pd.DataFrame(columns=['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB',
                                       'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source', 'Alpha Status'])
start_num = 41000000
end_num = start_num + len(nextgen_df)
nextgen_df['Source'] = "NextGen"
nextgen_df['Order Status'] = "In Process"
nextgen_df['Order Number'] = list(range(start_num, end_num))
nextgen_df['Order Date'] = '03-30-2023'
nextgen_df['Alpha Status'] = "Accepted"
orderbatch_df = orderbatch_df.append(nextgen_df, ignore_index = True)
with pd.ExcelWriter('NextGen Claim Review.xlsx') as writer:
    nextgen_raw.to_excel(writer, sheet_name='03-30-2023', index=False)
    # Get the worksheet object
    worksheet = writer.sheets['03-30-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\AlphaData\\PREP\\NextGen Claim Review.xlsx","C:\\AlphaData\\PREP\\March\\30\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-End-------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#









#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

habib_dups = pd.DataFrame()

habib_raw['Source'] = '03-30-2023'
habib_raw['Order Status'] = "InProcess"
habib_raw['Order Date'] = '03-30-2023'
habib_raw['Alpha Status'] = "Accepted"
habib_raw['Error'] = ""


cleaned_df = habib_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
habib_cleaned_df = habib_df.copy()

# Assign the 'comment' column to the new dataframe
habib_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
habib_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

habib_df.iloc[:, 3] = habib_df.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 4] = habib_df.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 5] = habib_df.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 6] = habib_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 7] = habib_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 8] = habib_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
habib_df.iloc[:, 9] = habib_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 10] = habib_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 11] = habib_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 12] = habib_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


habib_raw.iloc[:, 3] = habib_raw.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 4] = habib_raw.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 5] = habib_raw.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 6] = habib_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 7] = habib_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 8] = habib_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
habib_raw.iloc[:, 9] = habib_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 10] = habib_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 11] = habib_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 12] = habib_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)



habib_df['DOB'] = pd.to_datetime(habib_df['DOB']).dt.strftime('%m/%d/%Y')
habib_raw['DOB'] = pd.to_datetime(habib_raw['DOB']).dt.strftime('%m/%d/%Y')


habib_dups = habib_df[habib_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not habib_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=habib_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in habib_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            habib_df = habib_df.drop(group.index[1:])
            habib_raw.loc[habib_dups.index,'Source'] = "Habib"
            habib_raw.loc[habib_dups.index,'Error'] = "Duplicate Medicare ID"
            habib_raw.loc[habib_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            habib_df = habib_df.drop(group.index)
            habib_raw.loc[habib_dups.index,'Source'] = "Habib"
            habib_raw.loc[habib_dups.index,'Error'] = "Duplicate Medicare ID"
            habib_raw.loc[habib_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    habib_df = pd.concat([habib_df, unique_records])
    habib_raw = pd.concat([habib_raw, unique_records])


habib_mid_matches = habib_df[habib_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not habib_mid_matches.empty:
    habib_raw.loc[habib_mid_matches.index, 'Alpha Status'] = "Rejected"
    habib_raw.loc[habib_mid_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and MID List.")
    habib_df = habib_df.drop(habib_mid_matches.index)

habib_phone_matches = habib_df[habib_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not habib_phone_matches.empty:
    habib_raw.loc[habib_phone_matches.index, 'Alpha Status'] = "Rejected"
    habib_raw.loc[habib_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")
    habib_df = habib_df.drop(habib_phone_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
habib_order_matches = habib_df[habib_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not habib_order_matches.empty:
    habib_raw.loc[habib_order_matches.index, 'Alpha Status'] = "Rejected"
    habib_raw.loc[habib_order_matches.index, 'Error'] = "MID matched with MASTER MID List"
    print("Found medicare matches in Habib and Master MID List.")
    habib_df = habib_df.drop(habib_order_matches.index)

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(habib_df)
habib_df['Order Number'] = list(range(last_order_number, end_num))
habib_df['Source'] = "Habib"
habib_df['Order Status'] = "InProcess"
habib_df['Alpha Status'] = "Accepted"
habib_df['Order Date'] = '03-30-2023'
orderbatch_df = orderbatch_df.append(habib_df, ignore_index = True)
with pd.ExcelWriter('Habib Claim Review.xlsx') as writer:
    habib_raw.to_excel(writer, sheet_name='03-30-2023', index=False)
    worksheet = writer.sheets['03-30-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\AlphaData\\PREP\\Habib Claim Review.xlsx","C:\\AlphaData\\PREP\\March\\30\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#











"""
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------CPL---------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

cleaned_df = cpl_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
cpl_cleaned_df = cpl_df.copy()

# Assign the 'comment' column to the new dataframe
cpl_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']

cpl_raw.iloc[:, 3] = cpl_raw.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 4] = cpl_raw.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 5] = cpl_raw.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 6] = cpl_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 7] = cpl_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 8] = cpl_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
cpl_raw.iloc[:, 9] = cpl_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 10] = cpl_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 11] = cpl_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 12] = cpl_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)

cpl_df['DOB'] = pd.to_datetime(cpl_df['DOB']).dt.strftime('%m/%d/%Y')

cpl_dups = pd.DataFrame()

cpl_dups = cpl_df[cpl_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not cpl_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=cpl_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in cpl_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            unique_records = unique_records.append(group.iloc[0], ignore_index=True)
        else:
            # If not, delete all records in the group
            cpl_dups = cpl_dups.drop(group.index)
    
    # Append the unique records to the original dataframe
    cpl_df = pd.concat([cpl_df, unique_records])
    
if not cpl_dups.empty:
    # Add error message to the duplicate records
    cpl_dups['Error'] = "Duplicate Medicare Number!"
    cpl_dups['Source'] = 'CPL'
    print("Found duplicate values in MBI:\n", cpl_dups)

cpl_phone_matches = cpl_df[cpl_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not cpl_phone_matches.empty:
    cpl_df = cpl_df.drop(cpl_phone_matches.index)
    cpl_dups = pd.concat([cpl_dups, cpl_phone_matches])
    cpl_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in CPL and DNC.")

cpl_mid_matches = cpl_df[cpl_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not cpl_mid_matches.empty:
    cpl_df = cpl_df.drop(cpl_mid_matches.index)
    cpl_dups = pd.concat([cpl_dups, cpl_mid_matches])
    cpl_dups['Error'] = "Medicare # matched with MID List"
    print("Found medicare matches in CPL and MID.")

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
cpl_order_matches = cpl_df[cpl_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not cpl_order_matches.empty:
    cpl_df = cpl_df.drop(cpl_order_matches.index)
    cpl_dups = pd.concat([cpl_dups, cpl_order_matches])
    cpl_dups['Error'] = "Matched with the Master MID"
    print("Found medicare matches in CPL and Master MID List.")

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(cpl_df)
cpl_df['Order Number'] = list(range(last_order_number, end_num))
cpl_df['Source'] = "CPL"
cpl_df['Order Status'] = "InProcess"
cpl_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(cpl_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
with pd.ExcelWriter('CPL Completed 03_29_2023.xlsx') as writer:
    cpl_dups.to_excel(writer, sheet_name='CPL Duplicate Claim Orders', index=False)
    cpl_cleaned_df.to_excel(writer, sheet_name='CPL Cleanup Needed', index=False)

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------CPL-End-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
"""










#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Mitti---------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

mitti_dups = pd.DataFrame()

mitti_raw['Source'] = "Mitti"
mitti_raw['Order Status'] = "InProcess"
mitti_raw['Order Date'] = '03-30-2023'
mitti_raw['Alpha Status'] = "Accepted"
mitti_raw['Error'] = ""


cleaned_df = mitti_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
mitti_cleaned_df = mitti_df.copy()

# Assign the 'comment' column to the new dataframe
mitti_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
mitti_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

mitti_df.iloc[:, 3] = mitti_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 4] = mitti_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 5] = mitti_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 6] = mitti_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 7] = mitti_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 8] = mitti_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
mitti_df.iloc[:, 9] = mitti_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 10] = mitti_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 11] = mitti_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 12] = mitti_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


mitti_raw.iloc[:, 3] = mitti_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 4] = mitti_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 5] = mitti_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 6] = mitti_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 7] = mitti_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 8] = mitti_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
mitti_raw.iloc[:, 9] = mitti_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 10] = mitti_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 11] = mitti_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 12] = mitti_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


mitti_df['DOB'] = pd.to_datetime(mitti_df['DOB']).dt.strftime('%m/%d/%Y')
mitti_raw['DOB'] = pd.to_datetime(mitti_raw['DOB']).dt.strftime('%m/%d/%Y')


mitti_dups = mitti_df[mitti_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not mitti_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=mitti_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in mitti_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            mitti_df = mitti_df.drop(group.index[1:])
            mitti_raw.loc[mitti_dups.index,'Source'] = "Mitti"
            mitti_raw.loc[mitti_dups.index,'Error'] = "Duplicate Medicare ID"
            mitti_raw.loc[mitti_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            mitti_df = mitti_df.drop(group.index)
            mitti_raw.loc[mitti_dups.index,'Source'] = "Mitti"
            mitti_raw.loc[mitti_dups.index,'Error'] = "Duplicate Medicare ID"
            mitti_raw.loc[mitti_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    mitti_df = pd.concat([mitti_df, unique_records])
    mitti_raw = pd.concat([mitti_raw, unique_records])


mitti_mid_matches = mitti_df[mitti_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not mitti_mid_matches.empty:
    mitti_raw.loc[mitti_mid_matches.index, 'Alpha Status'] = "Rejected"
    mitti_raw.loc[mitti_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in Habib and DNC List.")
    mitti_df = mitti_df.drop(mitti_mid_matches.index)

mitti_phone_matches = mitti_df[mitti_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not mitti_phone_matches.empty:
    mitti_raw.loc[mitti_phone_matches.index, 'Alpha Status'] = "Rejected"
    mitti_raw.loc[mitti_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")
    mitti_df = mitti_df.drop(mitti_phone_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
mitti_order_matches = mitti_df[mitti_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not mitti_order_matches.empty:
    mitti_raw.loc[mitti_order_matches.index, 'Alpha Status'] = "Rejected"
    mitti_raw.loc[mitti_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in Habib and DNC List.")
    mitti_df = mitti_df.drop(mitti_order_matches.index)

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(mitti_df)
mitti_df['Order Number'] = list(range(last_order_number, end_num))
mitti_df['Source'] = "Mitti"
mitti_df['Order Status'] = "InProcess"
mitti_df['Order Date'] = '03-30-2023'
mitti_df['Alpha Status'] = "Accepted"
orderbatch_df = orderbatch_df.append(mitti_df, ignore_index = True)
with pd.ExcelWriter('Mitti Claim Review.xlsx') as writer:
    mitti_raw.to_excel(writer, sheet_name='03-30-2023', index=False)
    worksheet = writer.sheets['03-30-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\AlphaData\\PREP\\Mitti Claim Review.xlsx","C:\\AlphaData\\PREP\\March\\30\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Mitti-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#











#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------7Tel--------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

seventel_dups = pd.DataFrame()

seventel_raw['Source'] = "7Tel"
seventel_raw['Order Status'] = "InProcess"
seventel_raw['Order Date'] = '03-30-2023'
seventel_raw['Alpha Status'] = "Accepted"
seventel_raw['Error'] = ""


cleaned_df = seventel_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
seventel_cleaned_df = seventel_df.copy()

# Assign the 'comment' column to the new dataframe
seventel_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
seventel_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

seventel_df.iloc[:, 3] = seventel_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 4] = seventel_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 5] = seventel_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 6] = seventel_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 7] = seventel_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 8] = seventel_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
seventel_df.iloc[:, 9] = seventel_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 10] = seventel_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 11] = seventel_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 12] = seventel_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


seventel_raw.iloc[:, 3] = seventel_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 4] = seventel_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 5] = seventel_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 6] = seventel_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 7] = seventel_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 8] = seventel_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
seventel_raw.iloc[:, 9] = seventel_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 10] = seventel_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 11] = seventel_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 12] = seventel_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


seventel_df['DOB'] = pd.to_datetime(seventel_df['DOB']).dt.strftime('%m/%d/%Y')
seventel_raw['DOB'] = pd.to_datetime(seventel_raw['DOB']).dt.strftime('%m/%d/%Y')

seventel_dups = seventel_df[seventel_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not seventel_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=seventel_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in seventel_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            seventel_df = seventel_df.drop(group.index[1:])
            seventel_raw.loc[seventel_dups.index,'Source'] = "7Tel"
            seventel_raw.loc[seventel_dups.index,'Error'] = "Duplicate Medicare ID"
            seventel_raw.loc[seventel_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            seventel_df = seventel_df.drop(group.index)
            seventel_raw.loc[seventel_dups.index,'Source'] = "7Tel"
            seventel_raw.loc[seventel_dups.index,'Error'] = "Duplicate Medicare ID"
            seventel_raw.loc[seventel_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    seventel_df = pd.concat([seventel_df, unique_records])
    seventel_raw = pd.concat([seventel_raw, unique_records])


seventel_phone_matches = seventel_df[seventel_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not seventel_phone_matches.empty:
    seventel_raw.loc[seventel_phone_matches.index, 'Alpha Status'] = "Rejected"
    seventel_raw.loc[seventel_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")
    seventel_df = seventel_df.drop(seventel_phone_matches.index)

seventel_mid_matches = seventel_df[seventel_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not seventel_mid_matches.empty:
    seventel_raw.loc[seventel_mid_matches.index, 'Alpha Status'] = "Rejected"
    seventel_raw.loc[seventel_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in Habib and DNC List.")
    seventel_df = seventel_df.drop(seventel_mid_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
seventel_order_matches = seventel_df[seventel_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not seventel_order_matches.empty:
    seventel_raw.loc[seventel_order_matches.index, 'Alpha Status'] = "Rejected"
    seventel_raw.loc[seventel_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in Habib and DNC List.")
    seventel_df = seventel_df.drop(seventel_order_matches.index)

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(seventel_df)
seventel_df['Order Number'] = list(range(last_order_number, end_num))
seventel_df['Source'] = "7Tel"
seventel_df['Order Status'] = "InProcess"
seventel_df['Order Date'] = '03-30-2023'
seventel_df['Alpha Status'] = "Accepted"
orderbatch_df = orderbatch_df.append(seventel_df, ignore_index = True)
with pd.ExcelWriter('7Tel Claim Review.xlsx') as writer:
    seventel_raw.to_excel(writer, sheet_name='03-30-2023', index=False)
    worksheet = writer.sheets['03-30-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\AlphaData\\PREP\\7Tel Claim Review.xlsx","C:\\AlphaData\\PREP\\March\\30\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------7Tel-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#














#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------P1----------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

p1_dups = pd.DataFrame()

p1_raw['Source'] = "P1"
p1_raw['Order Status'] = "InProcess"
p1_raw['Order Date'] = '03-30-2023'
p1_raw['Alpha Status'] = "Accepted"
p1_raw['Error'] = ''


cleaned_df = p1_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
p1_cleaned_df = p1_df.copy()

# Assign the 'comment' column to the new dataframe
p1_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
p1_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

p1_df.iloc[:, 3] = p1_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 4] = p1_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 5] = p1_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 6] = p1_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 7] = p1_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 8] = p1_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
p1_df.iloc[:, 9] = p1_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 10] = p1_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 11] = p1_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 12] = p1_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


p1_raw.iloc[:, 3] = p1_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 4] = p1_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 5] = p1_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 6] = p1_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 7] = p1_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 8] = p1_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
p1_raw.iloc[:, 9] = p1_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 10] = p1_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 11] = p1_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 12] = p1_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


p1_df['DOB'] = pd.to_datetime(p1_df['DOB']).dt.strftime('%m/%d/%Y')
p1_raw['DOB'] = pd.to_datetime(p1_raw['DOB']).dt.strftime('%m/%d/%Y')

p1_dups = p1_df[p1_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not p1_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=p1_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in p1_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            p1_df = p1_df.drop(group.index[1:])
            p1_raw.loc[p1_dups.index,'Source'] = "P1"
            p1_raw.loc[p1_dups.index,'Error'] = "Duplicate Medicare ID"
            p1_raw.loc[p1_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            p1_df = p1_df.drop(group.index)
            p1_raw.loc[p1_dups.index,'Source'] = "P1"
            p1_raw.loc[p1_dups.index,'Error'] = "Duplicate Medicare ID"
            p1_raw.loc[p1_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    p1_df = pd.concat([p1_df, unique_records])
    p1_raw = pd.concat([p1_raw, unique_records])

p1_mid_matches = p1_df[p1_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not p1_mid_matches.empty:
    p1_raw.loc[p1_mid_matches.index, 'Alpha Status'] = "Rejected"
    p1_raw.loc[p1_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in Habib and DNC List.")
    p1_df = p1_df.drop(p1_mid_matches.index)

p1_phone_matches = p1_df[p1_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not p1_phone_matches.empty:
    p1_raw.loc[p1_phone_matches.index, 'Alpha Status'] = "Rejected"
    p1_raw.loc[p1_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")
    p1_df = p1_df.drop(p1_phone_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
p1_order_matches = p1_df[p1_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not p1_order_matches.empty:
    p1_raw.loc[p1_order_matches.index, 'Alpha Status'] = "Rejected"
    p1_raw.loc[p1_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in Habib and DNC List.")
    p1_df = p1_df.drop(p1_order_matches.index)

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(p1_df)
p1_df['Order Number'] = list(range(last_order_number, end_num))
p1_df['Source'] = "P1"
p1_df['Order Status'] = "InProcess"
p1_df['Order Date'] = '03-30-2023'
p1_df['Alpha Status'] = "Accepted"
orderbatch_df = orderbatch_df.append(p1_df, ignore_index = True)
with pd.ExcelWriter('P1 Claim Review.xlsx') as writer:
    p1_raw.to_excel(writer, sheet_name='03-30-2023', index=False)
    worksheet = writer.sheets['03-30-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

with pd.ExcelWriter('OrderBatch.xlsx') as writer2:
    orderbatch_df.to_excel(writer2, sheet_name='03-29-2023', index=False)
    worksheet2 = writer2.sheets['03-29-2023']
    for col in worksheet2.columns:
            col_letter = col[0].column_letter
            if col_letter >= 'A' and col_letter <= 'O':
                col_dimensions = worksheet2.column_dimensions[col_letter]
                col_dimensions.width = 20

shutil.move("C:\\AlphaData\\PREP\\P1 Claim Review.xlsx","C:\\AlphaData\\PREP\\March\\30\\")
shutil.move("C:\\AlphaData\\PREP\\OrderBatch.xlsx","C:\\AlphaData\\PREP\\March\\30\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------P1-End------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#










"""

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------BlueBells----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

bluebells_dups = pd.DataFrame()

bluebells_raw['Source'] = "BlueBells"
bluebells_raw['Order Status'] = "InProcess"
bluebells_raw['Order Date'] = '03-29-2023'
bluebells_raw['Error'] = ''
bluebells_raw['Alpha Status'] = "Accepted"


cleaned_df = bluebells_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Assign the 'comment' column to the new dataframe
bluebells_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

bluebells_df.iloc[:, 3] = bluebells_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 4] = bluebells_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 5] = bluebells_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 6] = bluebells_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 7] = bluebells_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 8] = bluebells_df.iloc[:, 8].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 9] = bluebells_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 10] = bluebells_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 11] = bluebells_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 12] = bluebells_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


bluebells_raw.iloc[:, 3] = bluebells_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 4] = bluebells_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 5] = bluebells_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 6] = bluebells_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 7] = bluebells_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 8] = bluebells_raw.iloc[:, 8].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 9] = bluebells_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 10] = bluebells_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 11] = bluebells_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 12] = bluebells_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


bluebells_df['DOB'] = pd.to_datetime(bluebells_df['DOB']).dt.strftime('%m/%d/%Y')
bluebells_raw['DOB'] = pd.to_datetime(bluebells_raw['DOB']).dt.strftime('%m/%d/%Y')

bluebells_dups = bluebells_df[bluebells_df.duplicated(subset=['MedicareNumber', 'First Name (Billing)', 'Last Name (Billing)'], keep= False)]
if not bluebells_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=bluebells_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in bluebells_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            bluebells_df = bluebells_df.drop(group.index[1:])
            bluebells_raw.loc[bluebells_dups.index,'Source'] = "BlueBells"
            bluebells_raw.loc[bluebells_dups.index,'Error'] = "Duplicate Medicare ID"
            bluebells_raw.loc[bluebells_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            bluebells_df = bluebells_df.drop(group.index)
            bluebells_raw.loc[bluebells_dups.index,'Source'] = "BlueBells"
            bluebells_raw.loc[bluebells_dups.index,'Error'] = "Duplicate Medicare ID"
            bluebells_raw.loc[bluebells_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    bluebells_df = pd.concat([bluebells_df, unique_records])
    bluebells_raw = pd.concat([bluebells_raw, unique_records])



bluebells_mid_matches = bluebells_df[bluebells_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not bluebells_mid_matches.empty:
    bluebells_raw.loc[bluebells_mid_matches.index, 'Alpha Status'] = "Rejected"
    bluebells_raw.loc[bluebells_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in Habib and DNC List.")
    bluebells_df = bluebells_df.drop(bluebells_mid_matches.index)


bluebells_phone_matches = bluebells_df[bluebells_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not bluebells_phone_matches.empty:
    bluebells_raw.loc[bluebells_phone_matches.index, 'Alpha Status'] = "Rejected"
    bluebells_raw.loc[bluebells_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")
    bluebells_df = bluebells_df.drop(bluebells_phone_matches.index)

bluebells_order_matches = bluebells_df[bluebells_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not bluebells_order_matches.empty:
    bluebells_raw.loc[bluebells_order_matches.index, 'Alpha Status'] = "Rejected"
    bluebells_raw.loc[bluebells_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in Habib and DNC List.")
    bluebells_df = bluebells_df.drop(bluebells_order_matches.index)

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(bluebells_df)
bluebells_df['Order Number'] = list(range(last_order_number, end_num))
bluebells_df['Source'] = "BlueBells"
bluebells_df['Order Status'] = "InProcess"
bluebells_df['Order Date'] = '03-29-2023'
bluebells_df['Alpha Status'] = "Accepted"
orderbatch_df = orderbatch_df.append(bluebells_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False, sheet_name = '03-29-2023')
with pd.ExcelWriter('BlueBells Claim Review.xlsx') as writer:
    bluebells_raw.to_excel(writer, sheet_name='03-29-2023', index=False)
    worksheet = writer.sheets['03-29-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 15

with pd.ExcelWriter('OrderBatch.xlsx') as writer2:
    orderbatch_df.to_excel(writer2, sheet_name='03-29-2023', index=False)
    worksheet2 = writer2.sheets['03-29-2023']
    for col in worksheet2.columns:
            col_letter = col[0].column_letter
            if col_letter >= 'A' and col_letter <= 'O':
                col_dimensions = worksheet2.column_dimensions[col_letter]
                col_dimensions.width = 20

shutil.move("C:\\AlphaData\\PREP\\BlueBells Claim Review.xlsx","C:\\AlphaData\\PREP\\March\\29\\")
shutil.move("C:\\AlphaData\\PREP\\OrderBatch.xlsx","C:\\AlphaData\\PREP\\March\\29\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------BlueBell-End------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#














#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Amigos----------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

cleaned_df = bluebells_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
bluebells_cleaned_df = bluebells_df.copy()

# Assign the 'comment' column to the new dataframe
bluebells_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']

bluebells_df.iloc[:, 3] = bluebells_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 4] = bluebells_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 5] = bluebells_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 6] = bluebells_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 7] = bluebells_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 8] = bluebells_df.iloc[:, 8].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 9] = bluebells_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 10] = bluebells_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 11] = bluebells_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 12] = bluebells_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)

bluebells_df['DOB'] = pd.to_datetime(bluebells_df['DOB']).dt.strftime('%d/%m/%Y')

bluebells_dups = pd.DataFrame()

bluebells_dups = bluebells_df[bluebells_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not bluebells_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=bluebells_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in bluebells_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            unique_records = unique_records.append(group.iloc[0], ignore_index=True)
        else:
            # If not, delete all records in the group
            bluebells_dups = bluebells_dups.drop(group.index)
    
    # Append the unique records to the original dataframe
    bluebells_df = pd.concat([bluebells_df, unique_records])
    
if not bluebells_dups.empty:
    # Add error message to the duplicate records
    bluebells_dups['Error'] = "Duplicate Medicare Number!"
    bluebells_dups['Source'] = 'P1'
    print("Found duplicate values in MBI:\n", bluebells_dups)

bluebells_phone_matches = bluebells_df[bluebells_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not bluebells_phone_matches.empty:
    bluebells_df = bluebells_df.drop(bluebells_phone_matches.index)
    bluebells_dups = pd.concat([bluebells_dups, bluebells_phone_matches])
    bluebells_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC.")

bluebells_mid_matches = bluebells_df[bluebells_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not bluebells_mid_matches.empty:
    bluebells_df = bluebells_df.drop(bluebells_mid_matches.index)
    bluebells_dups = pd.concat([bluebells_dups, bluebells_mid_matches])
    bluebells_dups['Error'] = "Medicare # matched with MID List"
    print("Found medicare matches in Habib and MID.")

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
bluebells_order_matches = bluebells_df[bluebells_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not bluebells_order_matches.empty:
    bluebells_df = bluebells_df.drop(bluebells_order_matches.index)
    bluebells_dups = pd.concat([bluebells_dups, bluebells_order_matches])
    bluebells_dups['Error'] = "Matched with the Master MID"
    print("Found medicare matches in Habib and MID.")

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(bluebells_df)
bluebells_df['Order Number'] = list(range(last_order_number, end_num))
bluebells_df['Source'] = "P1"
bluebells_df['Order Status'] = "InProcess"
bluebells_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(bluebells_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch 03_29_2023.xlsx', index = False)
with pd.ExcelWriter('P1 Completed 03_30_2023.xlsx') as writer:
    bluebells_dups.to_excel(writer, sheet_name='P1 Duplicate Claim Orders', index=False)
    bluebells_cleaned_df.to_excel(writer, sheet_name='P1 Cleanup Needed', index=False)

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Amigos-End-----------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

"""


