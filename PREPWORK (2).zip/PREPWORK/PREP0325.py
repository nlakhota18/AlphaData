import pandas as pd
import datetime

# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers.xlsx')
mid_df = pd.read_excel('Used MIDs.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= '03-25-2023')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '03-25-2023')
bluebells_df = pd.read_excel('BlueBells.xlsx', sheet_name= '03-25-2023')
sevtel_df = pd.read_excel('7Tel.xlsx', sheet_name = '03-25-2023')
cpl_df = pd.read_excel('CPL.xlsx', sheet_name= '03-25-2023')
habib_df = pd.read_excel('Habib.xlsx', sheet_name= '03-25-2023')


nextgen_duplicate_df = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])
mitti_duplicate_df = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])
bluebells_duplicate_df = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])
sevtel_duplicate_df = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])
cpl_duplicate_df = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])
habib_duplicate_df = pd.DataFrame(columns=['Last Name', 'First Name', 'Gender', 'Date of Birth (mm/dd/yy)', 'Medicare #', 'Address', 'City', 'State', 'Zip', 'Phone Number', 'Source', 'Error'])



now = datetime.datetime.now()









#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



nextgen_df.iloc[:, 0] = nextgen_df.iloc[:, 0].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 1] = nextgen_df.iloc[:, 1].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 2] = nextgen_df.iloc[:, 2].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].replace('[,. "\'-]', '', regex=True)

nextgen_df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(nextgen_df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')


duplicates_nextgen = nextgen_df[nextgen_df.duplicated(subset=['Medicare #'], keep= False)]
if not duplicates_nextgen.empty:
    for _, row in duplicates_nextgen.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_nextgen)
    nextgen_df = nextgen_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")
#to do: check to make sure duplicate are the same people, if so then delete, if not reject both.

# Merge the data frames based on the phone number column
merged_nextgen_dnc = pd.merge(nextgen_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncn_indexes = merged_nextgen_dnc.index
if not matching_dncn_indexes.empty:
    for _, row in matching_dncn_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the DNC List"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
nextgen_df = nextgen_df.drop(matching_dncn_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df, merged_nextgen_dnc])

nextgen_df.to_excel('NextGen.xlsx', index=False)
nextgen_df = pd.read_excel('NextGen.xlsx')


# Merge the data frames based on the phone number column
merged_nextgen_mid = pd.merge(nextgen_df, mid_df, how='inner',left_on='Medicare #',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midn_indexes = merged_nextgen_mid.index
if not matching_midn_indexes.empty:
    for _, row in matching_midn_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the MID List"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
nextgen_df = nextgen_df.drop(matching_midn_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df, merged_nextgen_mid])

nextgen_df.to_excel('NextGen.xlsx', index=False)
nextgen_df = pd.read_excel('NextGen.xlsx')


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
order_df = pd.DataFrame(columns=['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB', 'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source'])
# Append the data from the nextgen_df dataframe to the order_df dataframe
nextgen_order_df = nextgen_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
nextgen_order_df['Source'] = "NextGen" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
nextgen_order_df['Order Status'] = "In Process"
nextgen_order_df['Order Date'] = now.strftime('%m/%d/%Y')
nextgen_order_df['Order Number'] = 40000000
nextgen_order_df['Order Number'] = nextgen_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(nextgen_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index=False, header = True)
order_df = pd.read_excel('OrderBatch.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------NEXTGEN-END-------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
















#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------MITTI-------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



mitti_df.iloc[:, 0] = mitti_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 1] = mitti_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 2] = mitti_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 3] = mitti_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 4] = mitti_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 5] = mitti_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 6] = mitti_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 7] = mitti_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 8] = mitti_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 9] = mitti_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

mitti_df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(mitti_df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')


duplicates_mitti = mitti_df[mitti_df.duplicated(subset=['Medicare #'])]
if not duplicates_mitti.empty:
    for _, row in duplicates_mitti.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'Mitti'
        # append the duplicate record to duplicate_df
        mitti_duplicate_df = mitti_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_mitti)
    mitti_df = mitti_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")


# Merge the data frames based on the phone number column
merged_mitti_dnc = pd.merge(mitti_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncm_indexes = merged_mitti_dnc.index
if not matching_midn_indexes.empty:
    for _, row in matching_dncm_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the DNC List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'Mitti'
        # append the duplicate record to duplicate_df
        mitti_duplicate_df = mitti_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
mitti_df = mitti_df.drop(matching_dncm_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df, merged_mitti_dnc])

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')


# Merge the data frames based on the phone number column
merged_mitti_mid = pd.merge(mitti_df, mid_df, how='inner',left_on='Medicare #',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midm_indexes = merged_mitti_mid.index
if not matching_midm_indexes.empty:
    for _, row in matching_midm_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the MID List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'Mitti'
        # append the duplicate record to duplicate_df
        mitti_duplicate_df = mitti_duplicate_df.append(row)
mitti_df = mitti_df.drop(matching_midm_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df, merged_mitti_mid])

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')

merged_mitti_order_mid = pd.merge(mitti_df, order_df, how='inner',left_on='Medicare #',right_on='Medicare #')
matching_mid_mitti_order_indexes = merged_mitti_order_mid.index
if not matching_mid_mitti_order_indexes.empty:
    for _, row in matching_mid_mitti_order_indexes.iterrows():
        # create an error message
        error_msg = "Master Duplicate on MID!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'Mitti'
        # append the duplicate record to duplicate_df
        mitti_duplicate_df = mitti_duplicate_df.append(row)
mitti_df = mitti_df.drop(matching_mid_mitti_order_indexes)
mid_df = pd.concat([mid_df, merged_mitti_order_mid])

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
column_names = ['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB', 'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source']
mitti_df = mitti_df.reindex(columns=column_names)
# Append the data from the mitti_df dataframe to the order_df dataframe
mitti_order_df = mitti_df.copy() # create a copy of the mitti_df dataframe to avoid modifying the original dataframe
mitti_order_df['Source'] = "Mitti" # add a 'Source' column to the mitti_order_df dataframe and set the value to 'mitti'
mitti_order_df['Order Status'] = "In Process"
mitti_order_df['Order Date'] = now.strftime('%m/%d/%Y')
mitti_order_df['Order Number'] = mitti_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(mitti_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#------------------------------------------------------------------------MITTI-END------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#















#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#------------------------------------------------------------------------BlueBells------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



bluebells_df.iloc[:, 0] = bluebells_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 1] = bluebells_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 2] = bluebells_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 3] = bluebells_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 4] = bluebells_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 5] = bluebells_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 6] = bluebells_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 7] = bluebells_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 8] = bluebells_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 9] = bluebells_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

bluebells_df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(bluebells_df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')

duplicates_bluebells = bluebells_df[bluebells_df.duplicated(subset=['Medicare #'])]
if not duplicates_bluebells.empty:
    for _, row in duplicates_bluebells.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'BlueBells'
        # append the duplicate record to duplicate_df
        bluebells_duplicate_df = bluebells_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_bluebells)
    bluebells_df = bluebells_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_bluebells_dnc = pd.merge(bluebells_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncb_indexes = merged_bluebells_dnc.index
for _, row in matching_dncb_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the DNC List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'BlueBells'
        # append the duplicate record to duplicate_df
        bluebells_duplicate_df = bluebells_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
bluebells_df = bluebells_df.drop(matching_dncb_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df.reset_index(drop=True), merged_nextgen_dnc.reset_index(drop=True)], axis=0)

bluebells_df.to_excel('BlueBells.xlsx', index=False)
bluebells_df = pd.read_excel('BlueBells.xlsx')


# Merge the data frames based on the phone number column
merged_bluebells_mid = pd.merge(bluebells_df, mid_df, how='inner',left_on='Medicare #',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midb_indexes = merged_bluebells_mid.index
for _, row in matching_midb_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the MID List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'BlueBells'
        # append the duplicate record to duplicate_df
        bluebells_duplicate_df = bluebells_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
bluebells_df = bluebells_df.drop(matching_midb_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df.reset_index(drop=True), merged_bluebells_mid.reset_index(drop=True)], axis=0)

bluebells_df.to_excel('BlueBells.xlsx', index=False)
bluebells_df = pd.read_excel('BlueBells.xlsx')

merged_bluebells_order_mid = pd.merge(bluebells_df, order_df, how='inner',left_on='Medicare #',right_on='Medicare #')
matching_mid_bluebells_order_indexes = merged_bluebells_order_mid.index
for _, row in matching_mid_bluebells_order_indexes.iterrows():
        # create an error message
        error_msg = "Master Duplicate on MID!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'BlueBells'
        # append the duplicate record to duplicate_df
        bluebells_duplicate_df = bluebells_duplicate_df.append(row)
bluebells_df = bluebells_df.drop(matching_mid_bluebells_order_indexes)
mid_df = pd.concat([mid_df, merged_bluebells_order_mid])

bluebells_df.to_excel('BlueBells.xlsx', index=False)
bluebells_df = pd.read_excel('BlueBells.xlsx')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


bluebells_df = bluebells_df.reindex(columns=column_names)
# Append the data from the nextgen_df dataframe to the order_df dataframe
bluebells_order_df = bluebells_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
bluebells_order_df['Source'] = "BlueBells" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
bluebells_order_df['Order Status'] = "In Process"
bluebells_order_df['Order Date'] = now.strftime('%m/%d/%Y')
bluebells_order_df['Order Number'] = bluebells_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(bluebells_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#------------------------------------------------------------------------BLUEBELLS-END------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#














#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#------------------------------------------------------------------------7Tel-----------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



sevtel_df.iloc[:, 0] = sevtel_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 1] = sevtel_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 2] = sevtel_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 3] = sevtel_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 4] = sevtel_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 5] = sevtel_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 6] = sevtel_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 7] = sevtel_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 8] = sevtel_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
sevtel_df.iloc[:, 9] = sevtel_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

sevtel_df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(sevtel_df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')

duplicates_sevtel = sevtel_df[sevtel_df.duplicated(subset=['Medicare #'])]
if not duplicates_sevtel.empty:
    for _, row in duplicates_sevtel.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'BlueBells'
        # append the duplicate record to duplicate_df
        sevtel_duplicate_df = sevtel_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_sevtel)
    sevtel_df = sevtel_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_sevtel_dnc = pd.merge(sevtel_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncs_indexes = merged_sevtel_dnc.index
for _, row in matching_dncs_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the DNC List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        sevtel_duplicate_df = sevtel_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
sevtel_df = sevtel_df.drop(matching_dncs_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
sevtel_df = pd.concat([dnc_df.reset_index(drop=True), merged_sevtel_dnc.reset_index(drop=True)], axis=0)

sevtel_df.to_excel('BlueBells.xlsx', index=False)
sevtel_df = pd.read_excel('BlueBells.xlsx')


# Merge the data frames based on the phone number column
merged_sevtel_mid = pd.merge(sevtel_df, mid_df, how='inner',left_on='Medicare #',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_mids_indexes = merged_sevtel_mid.index
for _, row in matching_mids_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the MID List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        sevtel_duplicate_df = sevtel_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
sevtel_df = sevtel_df.drop(matching_mids_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df.reset_index(drop=True), merged_sevtel_mid.reset_index(drop=True)], axis=0)

sevtel_df.to_excel('BlueBells.xlsx', index=False)
sevtel_df = pd.read_excel('BlueBells.xlsx')

merged_sevtel_order_mid = pd.merge(sevtel_df, order_df, how='inner',left_on='Medicare #',right_on='Medicare #')
matching_mid_sevtel_order_indexes = merged_sevtel_order_mid.index
for _, row in matching_mid_sevtel_order_indexes.iterrows():
        # create an error message
        error_msg = "Master Duplicate on MID!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        sevtel_duplicate_df = sevtel_duplicate_df.append(row)
sevtel_df = sevtel_df.drop(matching_mid_sevtel_order_indexes)
mid_df = pd.concat([mid_df, merged_sevtel_order_mid])

sevtel_df.to_excel('BlueBells.xlsx', index=False)
sevtel_df = pd.read_excel('BlueBells.xlsx')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


sevtel_df = sevtel_df.reindex(columns=column_names)
# Append the data from the nextgen_df dataframe to the order_df dataframe
sevtel_order_df = sevtel_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
sevtel_order_df['Source'] = "BlueBells" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
sevtel_order_df['Order Status'] = "In Process"
sevtel_order_df['Order Date'] = now.strftime('%m/%d/%Y')
sevtel_order_df['Order Number'] = sevtel_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(sevtel_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#------------------------------------------------------------------------7TEL-END-------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


















#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------CPL------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



cpl_df.iloc[:, 0] = cpl_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 1] = cpl_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 2] = cpl_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 3] = cpl_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 4] = cpl_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 5] = cpl_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 6] = cpl_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 7] = cpl_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 8] = cpl_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 9] = cpl_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

cpl_df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(cpl_df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')

duplicates_cpl = cpl_df[cpl_df.duplicated(subset=['Medicare #'])]
if not duplicates_cpl.empty:
    for _, row in duplicates_cpl.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'BlueBells'
        # append the duplicate record to duplicate_df
        cpl_duplicate_df = cpl_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_cpl)
    cpl_df = cpl_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_cpl_dnc = pd.merge(cpl_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncc_indexes = merged_cpl_dnc.index
for _, row in matching_dncc_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the DNC List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        cpl_duplicate_df = cpl_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
cpl_df = cpl_df.drop(matching_dncc_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
cpl_df = pd.concat([dnc_df.reset_index(drop=True), merged_cpl_dnc.reset_index(drop=True)], axis=0)

cpl_df.to_excel('BlueBells.xlsx', index=False)
cpl_df = pd.read_excel('BlueBells.xlsx')


# Merge the data frames based on the phone number column
merged_cpl_mid = pd.merge(cpl_df, mid_df, how='inner',left_on='Medicare #',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midc_indexes = merged_cpl_mid.index
for _, row in matching_midc_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the MID List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        cpl_duplicate_df = cpl_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
cpl_df = cpl_df.drop(matching_midc_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df.reset_index(drop=True), merged_cpl_mid.reset_index(drop=True)], axis=0)

cpl_df.to_excel('BlueBells.xlsx', index=False)
cpl_df = pd.read_excel('BlueBells.xlsx')

merged_cpl_order_mid = pd.merge(cpl_df, order_df, how='inner',left_on='Medicare #',right_on='Medicare #')
matching_mid_cpl_order_indexes = merged_cpl_order_mid.index
for _, row in matching_mid_cpl_order_indexes.iterrows():
        # create an error message
        error_msg = "Master Duplicate on MID!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        cpl_duplicate_df = cpl_duplicate_df.append(row)
cpl_df = cpl_df.drop(matching_mid_cpl_order_indexes)
mid_df = pd.concat([mid_df, merged_cpl_order_mid])

cpl_df.to_excel('BlueBells.xlsx', index=False)
cpl_df = pd.read_excel('BlueBells.xlsx')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


cpl_df = cpl_df.reindex(columns=column_names)
# Append the data from the nextgen_df dataframe to the order_df dataframe
cpl_order_df = cpl_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
cpl_order_df['Source'] = "BlueBells" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
cpl_order_df['Order Status'] = "In Process"
cpl_order_df['Order Date'] = now.strftime('%m/%d/%Y')
cpl_order_df['Order Number'] = cpl_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(cpl_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------CPL-END----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#





















#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------HABIB------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



habib_df.iloc[:, 0] = habib_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 1] = habib_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 2] = habib_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 3] = habib_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 4] = habib_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 5] = habib_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 6] = habib_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 7] = habib_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 8] = habib_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
habib_df.iloc[:, 9] = habib_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

habib_df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(habib_df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')

duplicates_habib = habib_df[habib_df.duplicated(subset=['Medicare #'])]
if not duplicates_habib.empty:
    for _, row in duplicates_habib.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'BlueBells'
        # append the duplicate record to duplicate_df
        habib_duplicate_df = habib_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_cpl)
    habib_df = habib_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_habib_dnc = pd.merge(habib_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dnch_indexes = merged_habib_dnc.index
for _, row in matching_dnch_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the DNC List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        habib_duplicate_df = habib_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
habib_df = habib_df.drop(matching_dnch_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
habib_df = pd.concat([dnc_df.reset_index(drop=True), merged_habib_dnc.reset_index(drop=True)], axis=0)

habib_df.to_excel('BlueBells.xlsx', index=False)
habib_df = pd.read_excel('BlueBells.xlsx')


# Merge the data frames based on the phone number column
merged_habib_mid = pd.merge(habib_df, mid_df, how='inner',left_on='Medicare #',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midh_indexes = merged_habib_mid.index
for _, row in matching_midh_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the MID List!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        habib_duplicate_df = habib_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
habib_df = habib_df.drop(matching_midh_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
habib_df = pd.concat([mid_df.reset_index(drop=True), merged_habib_mid.reset_index(drop=True)], axis=0)

habib_df.to_excel('BlueBells.xlsx', index=False)
habib_df = pd.read_excel('BlueBells.xlsx')

merged_habib_order_mid = pd.merge(habib_df, order_df, how='inner',left_on='Medicare #',right_on='Medicare #')
matching_mid_habib_order_indexes = merged_habib_order_mid.index
for _, row in matching_mid_habib_order_indexes.iterrows():
        # create an error message
        error_msg = "Master Duplicate on MID!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = '7Tel'
        # append the duplicate record to duplicate_df
        habib_duplicate_df = habib_duplicate_df.append(row)
habib_df = habib_df.drop(matching_mid_habib_order_indexes)
mid_df = pd.concat([mid_df, merged_habib_order_mid])

habib_df.to_excel('BlueBells.xlsx', index=False)
habib_df = pd.read_excel('BlueBells.xlsx')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


habib_df = habib_df.reindex(columns=column_names)
# Append the data from the nextgen_df dataframe to the order_df dataframe
habib_order_df = habib_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
habib_order_df['Source'] = "BlueBells" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
habib_order_df['Order Status'] = "In Process"
habib_order_df['Order Date'] = now.strftime('%m/%d/%Y')
habib_order_df['Order Number'] = habib_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(habib_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------HABIB-END-------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#