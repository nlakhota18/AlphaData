import pandas as pd
import openpyxl
import shutil


# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers.xlsx')
mid_df = pd.read_excel('Used MIDs.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= '03-25-2023')
cpl_df = pd.read_excel('CPL.xlsx', sheet_name= '03-25-2023')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '03-25-2023')
bluebells_df = pd.read_excel('BlueBells.xlsx', sheet_name= '03-25-2023')

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


nextgen_df.iloc[:, 0] = nextgen_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 1] = nextgen_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 2] = nextgen_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

nextgen_df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(nextgen_df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')


duplicates_nextgen = nextgen_df[nextgen_df.duplicated(subset=['Medicare#'])]
if not duplicates_nextgen.empty:
    print("Found duplicate values in MBI:\n", duplicates_nextgen)
    nextgen_df = nextgen_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")


# Merge the data frames based on the phone number column
merged_nextgen_dnc = pd.merge(nextgen_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncn_indexes = merged_nextgen_dnc.index
# Drop the rows that match from the "mitti" data frame
nextgen_df = nextgen_df.drop(matching_dncn_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df, merged_nextgen_dnc])

nextgen_df.to_excel('NextGen.xlsx', index=False)
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '03-25-2023')


# Merge the data frames based on the phone number column
merged_nextgen_mid = pd.merge(nextgen_df, mid_df, how='inner',left_on='Medicare Number',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midn_indexes = merged_nextgen_mid.index
# Drop the rows that match from the "mitti" data frame
nextgen_df = nextgen_df.drop(matching_midn_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df, merged_nextgen_mid])

nextgen_df.to_excel('NextGen.xlsx', index=False)
dnc_df.to_excel('Used Phone Numbers.xlsx', index=False)
mid_df.to_excel('Used MIDs.xlsx', index=False)
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name='03-25-2023')
dnc_df = pd.read_excel('Used Phone Numbers.xlsx')
mid_df = pd.read_excel('Used MIDs.xlsx')


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


# create a new Excel file called "order.xlsx"
order_df = pd.DataFrame()
order_df.to_excel('OrderBatch.xlsx', index=False)

# load the "order" file as a data frame
order_df = pd.read_excel('OrderBatch.xlsx')
# copy the data from "mitti_df" into "order_df"

order_df = nextgen_df.copy()
order_df['Source'] = "NextGen"
# write the updated data to "order.xlsx"
order_df.to_excel('OrderBatch.xlsx', index=False)
order_df = pd.read_excel('OrderBatch.xlsx')


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


mitti_df.iloc[:, 0] = mitti_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 1] = mitti_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 2] = mitti_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 3] = mitti_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 4] = mitti_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 5] = mitti_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 6] = mitti_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 7] = mitti_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 8] = mitti_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
mitti_df.iloc[:, 9] = mitti_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

mitti_df['DOB'] = pd.to_datetime(mitti_df['DOB']).dt.strftime('%m/%d/%Y')


duplicates_mitti = mitti_df[mitti_df.duplicated(subset=['Medicare Number'])]
if not duplicates_mitti.empty:
    print("Found duplicate values in MBI:\n", duplicates_mitti)
    mitti_df = mitti_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")


# Merge the data frames based on the phone number column
merged_mitti_dnc = pd.merge(mitti_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncm_indexes = merged_mitti_dnc.index
# Drop the rows that match from the "mitti" data frame
mitti_df = mitti_df.drop(matching_dncm_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df, merged_mitti_dnc])

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')


# Merge the data frames based on the phone number column
merged_mitti_mid = pd.merge(mitti_df, mid_df, how='inner',left_on='Medicare Number',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midm_indexes = merged_mitti_mid.index
# Drop the rows that match from the "mitti" data frame
mitti_df = mitti_df.drop(matching_midm_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df, merged_mitti_mid])

mitti_df.to_excel('Mitti.xlsx', index=False)
dnc_df.to_excel('Used Phone Numbers.xlsx', index=False)
mid_df.to_excel('Used MIDs.xlsx', index=False)

merged_mitti_order_mid = pd.merge(mitti_df, order_df, how='inner',left_on='Medicare Number',right_on='Medicare Number')
matching_mid_mitti_order_indexes = merged_mitti_order_mid.index
mitti_df = mitti_df.drop(matching_mid_mitti_order_indexes)
mid_df = pd.concat([mid_df, merged_mitti_order_mid])

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


order_df = pd.concat([order_df, mitti_df])
order_df['Source'] = 'Mitti'
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

cpl_df.iloc[:, 0] = cpl_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 1] = cpl_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 2] = cpl_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 3] = cpl_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 4] = cpl_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 5] = cpl_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 6] = cpl_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 7] = cpl_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 8] = cpl_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
cpl_df.iloc[:, 9] = cpl_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

cpl_df['DOB'] = pd.to_datetime(cpl_df['DOB']).dt.strftime('%m/%d/%Y')

duplicates_cpl = cpl_df[cpl_df.duplicated(subset=['Medicare Number'])]
if not duplicates_cpl.empty:
    print("Found duplicate values in MBI:\n", duplicates_cpl)
    cpl_df = cpl_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_cpl_dnc = pd.merge(cpl_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncc_indexes = merged_cpl_dnc.index
# Drop the rows that match from the "mitti" data frame
cpl_df = cpl_df.drop(matching_dncc_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df, merged_cpl_dnc])

cpl_df.to_excel('CPL.xlsx', index=False)
cpl_df = pd.read_excel('Mitti.xlsx')


# Merge the data frames based on the phone number column
merged_cpl_mid = pd.merge(cpl_df, mid_df, how='inner',left_on='Medicare Number',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midc_indexes = merged_cpl_mid.index
# Drop the rows that match from the "mitti" data frame
cpl_df = cpl_df.drop(matching_midc_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df, merged_cpl_mid])

cpl_df.to_excel('CPL.xlsx', index=False)
cpl_df = pd.read_excel('Mitti.xlsx')

merged_cpl_order_mid = pd.merge(cpl_df, order_df, how='inner',left_on='Medicare Number',right_on='Medicare Number')
matching_mid_cpl_order_indexes = merged_cpl_order_mid.index
cpl_df = cpl_df.drop(matching_mid_cpl_order_indexes)
mid_df = pd.concat([mid_df, merged_cpl_order_mid])

cpl_df.to_excel('CPL.xlsx', index=False)
cpl_df = pd.read_excel('CPL.xlsx')

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


order_df = pd.concat([order_df, cpl_df])
order_df['Source'] = 'CPL'
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

bluebells_df.iloc[:, 0] = bluebells_df.iloc[:, 0].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 1] = bluebells_df.iloc[:, 1].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 2] = bluebells_df.iloc[:, 2].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 3] = bluebells_df.iloc[:, 3].replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 4] = bluebells_df.iloc[:, 4].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 5] = bluebells_df.iloc[:, 5].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 6] = bluebells_df.iloc[:, 6].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 7] = bluebells_df.iloc[:, 7].str.replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 8] = bluebells_df.iloc[:, 8].replace('[,. "\']', '', regex=True)
bluebells_df.iloc[:, 9] = bluebells_df.iloc[:, 9].replace('[,. "\']', '', regex=True)

bluebells_df['DOB'] = pd.to_datetime(bluebells_df['DOB']).dt.strftime('%m/%d/%Y')

duplicates_bluebells = bluebells_df[bluebells_df.duplicated(subset=['MBI'])]
if not duplicates_bluebells.empty:
    print("Found duplicate values in MBI:\n", duplicates_bluebells)
    bluebells_df = bluebells_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_bluebells_dnc = pd.merge(bluebells_df, dnc_df, how='inner', left_on='Phone Number', right_on='phone')
# Get the indexes of the rows that match
matching_dncb_indexes = merged_bluebells_dnc.index
# Drop the rows that match from the "mitti" data frame
bluebells_df = bluebells_df.drop(matching_dncb_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df, merged_bluebells_dnc])

bluebells_df.to_excel('BlueBells.xlsx', index=False)
bluebells_df = pd.read_excel('BlueBells.xlsx')


# Merge the data frames based on the phone number column
merged_bluebells_mid = pd.merge(bluebells_df, mid_df, how='inner',left_on='Medicare Number',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midb_indexes = merged_bluebells_mid.index
# Drop the rows that match from the "mitti" data frame
bluebells_df = bluebells_df.drop(matching_midb_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df, merged_bluebells_mid])

bluebells_df.to_excel('BlueBells.xlsx', index=False)
bluebells_df = pd.read_excel('BlueBells.xlsx')

merged_bluebells_order_mid = pd.merge(bluebells_df, order_df, how='inner',left_on='Medicare Number',right_on='Medicare Number')
matching_mid_bluebells_order_indexes = merged_bluebells_order_mid.index
bluebells_df = bluebells_df.drop(matching_mid_bluebells_order_indexes)
mid_df = pd.concat([mid_df, merged_bluebells_order_mid])

bluebells_df.to_excel('BlueBells.xlsx', index=False)
bluebells_df = pd.read_excel('BlueBells.xlsx')

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

order_df = pd.concat([order_df, bluebells_df])
order_df['Source'] = 'BlueBells'
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#