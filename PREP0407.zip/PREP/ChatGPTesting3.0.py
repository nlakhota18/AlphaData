import os
import openai
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
import requests
import datetime
import openpyxl
import pandas as pd
import concurrent.futures  # Import the concurrent.futures library for parallel processing
import shutil
from urllib.parse import urlparse

openai.api_key = "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"

mid_df = pd.read_excel('Used MIDs 0406.xlsx')
qa_sheet_df = pd.read_excel('Mitti Claim Review.xlsx', sheet_name='03-22-2023')
qa_sheet_df['Message'] = ""
qa_sheet_df['Tokens Used'] = ""

qa_sheet_df.iloc[:, 0] = qa_sheet_df.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 1] = qa_sheet_df.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 2] = qa_sheet_df.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 3] = qa_sheet_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 4] = qa_sheet_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 5] = qa_sheet_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
qa_sheet_df.iloc[:, 6] = qa_sheet_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 7] = qa_sheet_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 8] = qa_sheet_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
qa_sheet_df.iloc[:, 9] = qa_sheet_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)

qa_sheet_dups = qa_sheet_df[qa_sheet_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not qa_sheet_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=qa_sheet_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in qa_sheet_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            nextgen_df = nextgen_df.drop(group.index[1:])
        else:
            # If not, delete all records in the group
            nextgen_df = nextgen_df.drop(group.index)

qa_mid_matches = qa_sheet_df[qa_sheet_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not qa_mid_matches.empty:
    print("Found MID matches in Mitti and MID List.")
    qa_sheet_df = qa_sheet_df.drop(qa_mid_matches.index)

shutil.os.makedirs("C:\\AlphaData\\Recordings\\NextGen\\April\\7")
# Create a function to download the recordings from the URL links
def download_recording(url, index):
    try:
        if pd.isna(url):  # Check if the url is empty
            skip = "skip"
            print(f"Skipping {url}")
            return None
        
        parsed_url = urlparse(url)
        if not parsed_url.scheme:
            url = "https://" + url

        response = requests.get(url, timeout=10, verify=False)
  # increase the timeout to 10 seconds
        if response.status_code == 200:
            filename = "C:\\AlphaData\\Recordings\\NextGen\\April\\7\\" + str(df.iloc[index]['Medicare#']).replace('\t', '').replace('\n', '').replace('::::','').replace('::','').replace(':','').replace('/','').replace(' ', '') + '.mp3'
            with open(filename, 'wb') as f:
                f.write(response.content)
            print(f"Successfully downloaded {url}")
            return filename
        else:
            # If the request is not successful, return None
            print(f"Error downloading {url}")
            return None
    except requests.exceptions.Timeout:
        # If the download times out, return None
        print(f"Timeout error downloading {url}")
        return None
    except requests.exceptions.ConnectionError:
        print(f"Connection error downloading {url}")
        return None



# Create a new workbook and worksheet
workbook = openpyxl.Workbook()
worksheet = workbook.active
worksheet.title = 'NG_04-07-2023_ALPHA'

# Add headers to the worksheet
headers = ['Timestamp', 'Last Name', 'First Name', 'Gender', 'DOB', 'MBI Number', 'Address', 'Customer City', 'State', 'Zip', 'Contact Number', 'Pverify', 'Recordings Links', 'ALPHA_Timestamp', 'Downloaded?', 'Error Comment:', 'FirstName Matched', 'LastName Matched', 'DOB Matched', 'Address Matched', 'MBI Number Matched', 'Gave Consent?']
worksheet.append(headers)

# Save the workbook
workbook.save('NG_04-07-2023_ALPHA.xlsx')

# Open the workbook again in append mode
workbook = openpyxl.load_workbook('NG_04-07-2023_ALPHA.xlsx')
worksheet = workbook.active

for column in worksheet.columns:
    max_length = 0
    column_name = column[0].column_letter
    for cell in column:
        try:
            if len(str(cell.value)) > max_length:
                max_length = len(str(cell.value))
        except:
            pass
    adjusted_width = (max_length + 2) * 2
    worksheet.column_dimensions[column_name].width = adjusted_width

# Start the loop to read URLs from somewhere
now = datetime.datetime.now()
df = pd.read_excel("C:\\AlphaData\\NextGen\\NextGen TechLeads.xlsx", sheet_name='03-22-2023')
df['Time Stamp'] = pd.to_datetime(df['Time Stamp']).dt.strftime('%m/%d/%Y')
df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')

# Use the concurrent.futures library to process the URL links in parallel
with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for index, row in df.iterrows():
        link = row[11]
        mbinumber = row[5]

        # Submit the URL link to
        futures.append(executor.submit(download_recording, link, index))

    future = concurrent.futures.as_completed(futures)
    for index, result in enumerate(future):
        filename = result.result()
        if filename:
            worksheet.append([df.iloc[index][0], df.iloc[index][1], df.iloc[index][2], df.iloc[index][3], df.iloc[index][4], df.iloc[index][5], df.iloc[index][6], df.iloc[index][7], df.iloc[index][8], df.iloc[index][9],df.iloc[index][10], "N/A", df.iloc[index][11], now.strftime("%Y-%m-%d %I:%M:%S %p"),"YES", ""])
        else:
            worksheet.append([df.iloc[index][0], df.iloc[index][1], df.iloc[index][2], df.iloc[index][3], df.iloc[index][4], df.iloc[index][5], df.iloc[index][6], df.iloc[index][7], df.iloc[index][8], df.iloc[index][9],df.iloc[index][10], "N/A", df.iloc[index][11], now.strftime("%Y-%m-%d %I:%M:%S %p"),"NO", "Error Downloading caused by Connection or Timeout Error!"])

        # Save the workbook after every download
        workbook.save('M_03-22-2023_ALPHA.xlsx')

shutil.move("C:\\AlphaData\\Recordings\\Mitti\\M_03-22-2023_ALPHA.xlsx","C:\\AlphaData\\Recordings\\Mitti\\March\\22\\")

workbook.close()

# Analyze text using OpenAI API
def analyze_text(transcript):
    model_engine = "text-davinci-003"
    # Modify prompt to ask a direct yes/no question and provide more context
    prompt = (
        f"The following transcript is a call between an agent and an individual, the agent first verifies the individuals information and then proceeds to question whether the individual would like to enroll or receive covid-19 kits with no cost.:\n{transcript}\n"
         "Based on the transcript provided, did the customer in the conversation explicitly give consent or a clear agreement to receive the free COVID test kits from the agent?"
    )
    
    tokens_usedp = len(prompt.split())

    try:
        completions = openai.Completion.create(
            engine=model_engine,
            prompt=prompt,
            max_tokens=200,
            n=1,
            stop=None,
            temperature=0.4,
        )
        message = completions.choices[0].text.strip()
        tokens_used = len(completions.choices[0].text.split())
        tokens_used = tokens_used + tokens_usedp
        print(tokens_used)
    except Exception as error:
        message = f"Error: {error}"
        tokens_used = 0
    return message, tokens_used

# Set path to folder containing mp3 files
path_to_folder = "C:\\AlphaData\\Recordings\\NextGen\\April\\7\\"
results = []

with ThreadPoolExecutor(max_workers=8) as executor:
    # Iterate over mp3 files in folder
    for filename in os.listdir(path_to_folder):
        if filename.endswith(".mp3"):
            # Load audio file
            audio_file = open(os.path.join(path_to_folder, filename), "rb")
            
            # Submit analyze_text function to executor
            future = executor.submit(openai.Audio.transcribe, "whisper-1", audio_file, speaker_labels=True)
            
            # Append the future object to a list for later processing
            results.append(future)
# Iterate over mp3 files in folder
for filename in os.listdir(path_to_folder):
    if filename.endswith(".mp3"):
        # Extract Medicare ID from filename
        medicare_id = filename.split(".")[0]
        # Check if Medicare ID exists in Mitti Claim Review Excel sheet
        if medicare_id in qa_sheet_df['MedicareNumber'].str.slice(stop=9).tolist():
            # Load audio file
            audio_file = open(os.path.join(path_to_folder, filename), "rb")
            # Submit analyze_text function to executor
            future = openai.Audio.transcribe("whisper-1", audio_file, speaker_labels=True)
            # Get transcript from future object
            transcript = future.result()
            # Analyze text using OpenAI API
            message, tokens_used = analyze_text(transcript)
            # Locate row in qa_sheet_df that matches the Medicare ID and Medicare #
            qa_sheet_df.loc[qa_sheet_df['MedicareNumber'] == medicare_id, 'Message'] = message
            qa_sheet_df.loc[qa_sheet_df['MedicareNumber'] == medicare_id, 'Tokens Used'] = tokens_used




with pd.ExcelWriter('Mitti Final Claim Review.xlsx') as writer:
    qa_sheet_df.to_excel(writer, sheet_name='03-22-2023', index=False)
    worksheet = writer.sheets['03-22-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'T':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

