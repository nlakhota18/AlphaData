import openai
import os

openai.api_key = "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"

# Load audio file
audio_file = open("C:\\AlphaData\\PREP\\NO\\8EN3TV0GE82.mp3", "rb")

# Set model and engine parameters
model = "audio-adapter"
engine = "davinci"

# Set additional parameters for audio transcription
params = {
    "Speaker_Labels": True,
    "Language": "en-US",
    "Audio_Format": "wav",
    "Audio_Channels": 1
}

# Call the OpenAI API to transcribe the audio file
response = openai.Completion.create(
    model=model,
    engine=engine,
    audio=audio_file,
    prompt="Transcribe the following audio:",
    max_tokens=1024,
    n=1,
    stop=None,
    temperature=0.5,
    **params
)

# Extract the transcription and speaker labels from the response
transcription = response.choices[0].text
speaker_labels = response.choices[0].metadata['speaker_labels']

# Print the transcription and speaker labels
print(transcription)
print(speaker_labels)
