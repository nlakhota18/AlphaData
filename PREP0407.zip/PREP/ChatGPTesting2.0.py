import os
import openai
import pandas as pd
from concurrent.futures import ThreadPoolExecutor

openai.api_key = "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"


# Analyze text using OpenAI API
def analyze_text(transcript):
    model_engine = "text-davinci-003"
    # Modify prompt to ask a direct yes/no question and provide more context
    prompt = (
        f"The following transcript is a call between an agent and an individual, the agent first verifies the individuals information and then proceeds to question whether the individual would like to enroll or receive covid-19 kits with no cost.:\n{transcript}\n"
         "Based on the transcript provided, did the customer in the conversation explicitly give consent or a clear agreement to receive the free COVID test kits from the agent?"
    )
    
    tokens_usedp = len(prompt.split())

    try:
        completions = openai.Completion.create(
            engine=model_engine,
            prompt=prompt,
            max_tokens=200,
            n=1,
            stop=None,
            temperature=0.4,
        )
        message = completions.choices[0].text.strip()
        tokens_used = len(completions.choices[0].text.split())
        tokens_used = tokens_used + tokens_usedp
        print(tokens_used)
    except Exception as error:
        message = f"Error: {error}"
        tokens_used = 0
    return message, tokens_used

# Set path to folder containing mp3 files
path_to_folder = "C:\\AlphaData\\Recordings\\NextGen\\April\\7\\"

# Create empty list to store results
results = []

# Create ThreadPoolExecutor with 4 threads
with ThreadPoolExecutor(max_workers=8) as executor:
    # Iterate over mp3 files in folder
    for filename in os.listdir(path_to_folder):
        if filename.endswith(".mp3"):
            # Load audio file
            audio_file = open(os.path.join(path_to_folder, filename), "rb")
            
            # Submit analyze_text function to executor
            future = executor.submit(openai.Audio.transcribe, "whisper-1", audio_file, speaker_labels=True)
            
            # Append the future object to a list for later processing
            results.append(future)

# Iterate over futures and extract results
for i, future in enumerate(results):
    filename = os.listdir(path_to_folder)[i]
    if filename.endswith(".mp3"):
        # Get transcript from future object
        transcript = future.result()
        
        # Analyze text using OpenAI API
        message, tokens_used = analyze_text(transcript)
        
        # Add filename, message, and tokens used to results list
        results[i] = [filename, message, tokens_used]

# Convert results to DataFrame and write to Excel file
df = pd.DataFrame(results, columns=["Filename", "Message", "Tokens Used"])
df.to_excel("davinciYESLIST6.xlsx", index=False)


