import openai

openai.api_key = "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"


audio_file = open("C:\\AlphaData\\PREP\\NO\\8EN3TV0GE82.mp3", "rb")
transcript = openai.Audio.transcribe("whisper-1", audio_file, speaker_labels=True)

print(transcript)


