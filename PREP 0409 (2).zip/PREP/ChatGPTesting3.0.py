import os
import openai
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
import requests
import datetime
import openpyxl
import pandas as pd
import concurrent.futures  # Import the concurrent.futures library for parallel processing
import shutil
from urllib.parse import urlparse

openai.api_key = "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"

qa_sheet_df = pd.read_excel('NextGen.xlsx', sheet_name='test')
qa_sheet_df['Message'] = ""
qa_sheet_df['Tokens Used'] = ""

shutil.os.makedirs("C:\\Users\\Nakib\\Downloads\\PREP\\ChatGPTApril\\8")
# Create a function to download the recordings from the URL links
def download_recording(url, index):
    try:
        if pd.isna(url):  # Check if the url is empty
            skip = "skip"
            print(f"Skipping {url}")
            return None
        
        parsed_url = urlparse(url)
        if not parsed_url.scheme:
            url = "https://" + url

        response = requests.get(url, timeout=10, verify=False)
  # increase the timeout to 10 seconds
        if response.status_code == 200:
            filename = "C:\\Users\\Nakib\\Downloads\\PREP\\ChatGPTApril\\8\\" + str(df.iloc[index]['Medicare#']).replace('\t', '').replace('\n', '').replace('::::','').replace('::','').replace(':','').replace('/','').replace(' ', '') + '.mp3'
            with open(filename, 'wb') as f:
                f.write(response.content)
            print(f"Successfully downloaded {url}")
            return filename
        else:
            # If the request is not successful, return None
            print(f"Error downloading {url}")
            return None
    except requests.exceptions.Timeout:
        # If the download times out, return None
        print(f"Timeout error downloading {url}")
        return None
    except requests.exceptions.ConnectionError:
        print(f"Connection error downloading {url}")
        return None



# Create a new workbook and worksheet
workbook = openpyxl.Workbook()
worksheet = workbook.active
worksheet.title = 'NG_04-08-2023_ALPHA'

# Add headers to the worksheet
headers = ['Timestamp', 'Last Name', 'First Name', 'Gender', 'DOB', 'MBI Number', 'Address', 'Customer City', 'State', 'Zip', 'Contact Number', 'Pverify', 'Recordings Links', 'ALPHA_Timestamp', 'Downloaded?', 'Error Comment:']
worksheet.append(headers)

# Save the workbook
workbook.save('NG_04-08-2023_ALPHA.xlsx')

# Open the workbook again in append mode
workbook = openpyxl.load_workbook('NG_04-08-2023_ALPHA.xlsx')
worksheet = workbook.active

for column in worksheet.columns:
    max_length = 0
    column_name = column[0].column_letter
    for cell in column:
        try:
            if len(str(cell.value)) > max_length:
                max_length = len(str(cell.value))
        except:
            pass
    adjusted_width = (max_length + 2) * 2
    worksheet.column_dimensions[column_name].width = adjusted_width

# Start the loop to read URLs from somewhere
now = datetime.datetime.now()
df = pd.read_excel("C:\\Users\\Nakib\\Downloads\\PREP\\NextGen.xlsx", sheet_name='test')
df['Time Stamp'] = pd.to_datetime(df['Time Stamp']).dt.strftime('%m/%d/%Y')
df['Date of Birth (mm/dd/yy)'] = pd.to_datetime(df['Date of Birth (mm/dd/yy)']).dt.strftime('%m/%d/%Y')

df.iloc[:, 5] = df.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)

# Use the concurrent.futures library to process the URL links in parallel
# Use the concurrent.futures library to process the URL links in parallel
with concurrent.futures.ThreadPoolExecutor(max_workers = 8) as executor:
    futures = []
    for index, row in df.iterrows():
        link = row[11]
        mbinumber = row[6]

        # Submit the URL link to
        futures.append(executor.submit(download_recording, link, index))

    for index, future in enumerate(concurrent.futures.as_completed(futures)):
        filename = future.result()
        if filename:
            row_data = [df.iloc[index][0], df.iloc[index][1], df.iloc[index][2], df.iloc[index][3], df.iloc[index][4], df.iloc[index][5], df.iloc[index][6], df.iloc[index][7], df.iloc[index][8], df.iloc[index][9],df.iloc[index][10], "N/A", df.iloc[index][11], now.strftime("%Y-%m-%d %I:%M:%S %p"),"YES", ""]
            worksheet.append(row_data)
        else:
            row_data = [df.iloc[index][0], df.iloc[index][1], df.iloc[index][2], df.iloc[index][3], df.iloc[index][4], df.iloc[index][5], df.iloc[index][6], df.iloc[index][7], df.iloc[index][8], df.iloc[index][9],df.iloc[index][10], "N/A", df.iloc[index][11], now.strftime("%Y-%m-%d %I:%M:%S %p"),"NO", "Error Downloading caused by Connection or Timeout Error!"]
            worksheet.append(row_data)

# Save the workbook after every download
workbook.save('NG_04-08-2023_ALPHA.xlsx')

shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\NG_04-08-2023_ALPHA.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\ChatGPTApril\\8")

workbook.close()


qa_sheet_df = pd.read_excel("C:\\Users\\Nakib\\Downloads\\PREP\\ChatGPTApril\8\\NG_04-08-2023_ALPHA.xlsx")
qa_sheet_df['Message'] = ""
qa_sheet_df['Tokens Used'] = ""

qa_sheet_df = qa_sheet_df.loc[qa_sheet_df['Downloaded?'] == "YES"]
qa_sheet_df = qa_sheet_df.drop('Error Comment:',axis=1)

# Analyze text using OpenAI API
def analyze_text(transcript):
    model_engine = "text-davinci-003"
    # Modify prompt to ask a direct yes/no question and provide more context
    prompt = (
        f"Please analyze the transcript of a call between an agent and an individual where the agent verifies the individual's personal information and then offers a program for COVID-19 kits. Towards the end of the call, the agent asks for consent to send COVID-19 kits or enroll them to receive COVID-19 kits every month for free.:\n{transcript}\n" 
        "Based on the transcript, did the customer give consent, or was okay to receive the COVID kits?"
    )
    
    tokens_usedp = len(prompt.split())

    try:
        completions = openai.Completion.create(
            engine=model_engine,
            prompt=prompt,
            max_tokens=200,
            n=1,
            stop=None,
            temperature=0.4,
        )
        message = completions.choices[0].text.strip()
        tokens_used = len(completions.choices[0].text.split())
        tokens_used = tokens_used + tokens_usedp
        print(tokens_used)
    except Exception as error:
        message = f"Error: {error}"
        tokens_used = 0
    return message, tokens_used

# Set path to folder containing mp3 files
path_to_folder = "C:\\Users\\Nakib\\Downloads\\PREP\\ChatGPTApril\\8"
results = []

with ThreadPoolExecutor(max_workers=8) as executor:
    # Iterate over mp3 files in folder
    for filename in os.listdir(path_to_folder):
        if filename.endswith(".mp3"):
            # Load audio file
            audio_file = open(os.path.join(path_to_folder, filename), "rb")
            
            # Submit analyze_text function to executor
            future = executor.submit(openai.Audio.transcribe, "whisper-1", audio_file, speaker_labels=True)
            
            # Append the future object to a list for later processing
            results.append(future)


for i, future in enumerate(results):
    filename = os.listdir(path_to_folder)[i]
    if filename.endswith(".mp3"):
        # Get transcript from future object
        medicare_id = filename.split(".")[0]
        transcript = future.result()
        
        # Analyze text using OpenAI API
        message, tokens_used = analyze_text(transcript)
        
        # Add filename, message, and tokens used to results list
        results[i] = [filename, message, tokens_used]
        medicare_matched = qa_sheet_df[qa_sheet_df['MBI Number'] == medicare_id]

            # Set 'Tokens Used' and 'Consent Message' values for current row
        qa_sheet_df.loc[medicare_matched.index, 'Consent Message'] = message
        qa_sheet_df.loc[medicare_matched.index, 'Tokens Used'] = tokens_used

with pd.ExcelWriter('NextGen Davinci Test.xlsx') as writer:
    qa_sheet_df.to_excel(writer, sheet_name='04-08-2023', index=False)
    worksheet = writer.sheets['04-08-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'T':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

