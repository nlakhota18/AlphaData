import pandas as pd
import datetime
import re
import openpyxl
import shutil


shutil.os.makedirs("C:\\Users\\Nakib\\Downloads\\PREP\\April\\8")
# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers 0408.xlsx')
mid_df = pd.read_excel('Used MIDs 0408.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= '04-08-2023')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '04-08-2023')
habib_df = pd.read_excel('Habib.xlsx', sheet_name= '04-08-2023')
#cpl_df = pd.read_excel('CPL.xlsx', sheet_name= '04-07-2023')
#seventel_df = pd.read_excel('7Tel.xlsx', sheet_name= '04-07-2023')
p1_df = pd.read_excel('P1.xlsx', sheet_name= '04-08-2023')
bluebells_df = pd.read_excel('BlueBells.xlsx', sheet_name= '04-07-2023')
#amigos_df = pd.read_excel('Amigos.xlsx', sheet_name= '03-31-2023')
#telemax_df = pd.read_excel('Telemax.xlsx', sheet_name= '')


nextgen_raw = nextgen_df.copy()
#cpl_raw = cpl_df.copy()
habib_raw = habib_df.copy()
mitti_raw = mitti_df.copy()
bluebells_raw = bluebells_df.copy()
#seventel_raw = seventel_df.copy()
#amigos_raw = amigos_df.copy()
p1_raw = p1_df.copy()
#telemax_raw = telemax_df.copy()



now = datetime.datetime.now()


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

nextgen_dups = pd.DataFrame()

# Assuming you have a DataFrame called 'habib_df'
nextgen_df['First Name (Billing)'] = nextgen_df['First Name (Billing)'].str.upper()
nextgen_df['Last Name (Billing)'] = nextgen_df['Last Name (Billing)'].str.upper()


nextgen_raw['Source'] = "NextGen"
nextgen_raw['Order Status'] = "InProcess"
nextgen_raw['Order Date'] = '04-08-2023'
nextgen_raw['Alpha Status'] = "Accepted"
nextgen_raw = nextgen_raw.drop('Recording Links', axis = 1)
nextgen_raw['Processed Date'] = '04-09-2023'
nextgen_raw['Error'] = ""
nextgen_raw['Alpha Comment'] = ""
nextgen_raw['Recording Links'] = nextgen_df['Recording Links']



def clean_string(s):
    s = str(s)
    s = re.sub(r'[^\w\s]', '', s)  # remove all characters except for letters, digits, and whitespace
    s = re.sub(r'[\n]', '', s)  # remove newlines
    return s.strip()

def clean_row(row):
    cleaned_row = [clean_string(value) for value in row]
    comment = ', '.join(f"replace '{old}' with '{new}'" for old, new in zip(row, cleaned_row) if old != new)
    if not comment:
        comment = ''
    return cleaned_row, comment

# Apply the clean_row function to each row of the specified columns
columns_to_clean = [3,4,5,7,8,9,10]
cleaned_df = nextgen_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']


# Make a copy of the original dataframe
nextgen_cleaned_df = nextgen_df.copy()

# Assign the 'comment' column to the new dataframe
nextgen_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
nextgen_raw['Alpha Comment'] = cleaned_df['Alpha Comment']


nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 10] = nextgen_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 11] = nextgen_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_df.iloc[:, 12] = nextgen_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)

nextgen_raw.iloc[:, 3] = nextgen_raw.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 4] = nextgen_raw.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 5] = nextgen_raw.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 6] = nextgen_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 7] = nextgen_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 8] = nextgen_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
nextgen_raw.iloc[:, 9] = nextgen_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 10] = nextgen_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 11] = nextgen_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
nextgen_raw.iloc[:, 12] = nextgen_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)



nextgen_df['DOB'] = pd.to_datetime(nextgen_df['DOB']).dt.strftime('%m/%d/%Y')
nextgen_raw['DOB'] = pd.to_datetime(nextgen_raw['DOB']).dt.strftime('%m/%d/%Y')


# Merge the cleaned columns back into the original dataframe

nextgen_dups = nextgen_df[nextgen_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not nextgen_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=nextgen_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in nextgen_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            nextgen_df = nextgen_df.drop(group.index[1:])
            nextgen_raw.loc[nextgen_dups.index,'Source'] = "NextGen"
            nextgen_raw.loc[nextgen_dups.index,'Error'] = "Duplicate Medicare ID"
            nextgen_raw.loc[nextgen_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            nextgen_df = nextgen_df.drop(group.index)
            nextgen_raw.loc[nextgen_dups.index,'Source'] = "NextGen"
            nextgen_raw.loc[nextgen_dups.index,'Error'] = "Duplicate Medicare ID"
            nextgen_raw.loc[nextgen_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    nextgen_df = pd.concat([nextgen_df, unique_records])
    nextgen_raw = pd.concat([nextgen_raw, unique_records])


nextgen_mid_matches = nextgen_df[nextgen_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not nextgen_mid_matches.empty:
    nextgen_raw.loc[nextgen_mid_matches.index, 'Alpha Status'] = "Rejected"
    nextgen_raw.loc[nextgen_mid_matches.index, 'Order Status'] = "Rejected"
    nextgen_raw.loc[nextgen_mid_matches.index, 'Error'] = "Medicare Number matched with MID List"
    print("Found phone matches in NextGen and MID List.")
    nextgen_df = nextgen_df.drop(nextgen_mid_matches.index)


nextgen_df['Phone (Billing)'] = nextgen_df['Phone (Billing)'].astype(str)
nextgen_phone_matches = nextgen_df[nextgen_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not nextgen_phone_matches.empty:
    nextgen_raw.loc[nextgen_phone_matches.index, 'Alpha Status'] = "Rejected"
    nextgen_raw.loc[nextgen_phone_matches.index, 'Order Status'] = "Rejected"
    nextgen_raw.loc[nextgen_phone_matches.index, 'Alpha Status'] = "Phone Number matched with DNC List"
    print("Found phone matches in NextGen and DNC List.")
    nextgen_df = nextgen_df.drop(nextgen_phone_matches.index)



orderbatch_df = pd.DataFrame(columns=['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB',
                                       'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source', 'Alpha Status'])
start_num = 42008264
end_num = start_num + len(nextgen_df)
nextgen_df['Source'] = "NextGen"
nextgen_df['Order Status'] = "In Process"
nextgen_df['Order Number'] = list(range(start_num, end_num))
nextgen_df['Order Date'] = '04-08-2023'
nextgen_df['Alpha Status'] = "Accepted"
orderbatch_df = pd.concat([orderbatch_df, nextgen_df], ignore_index=True)
with pd.ExcelWriter('NextGen Claim Review 04-08-2023.xlsx') as writer:
    nextgen_raw.to_excel(writer, sheet_name='04-08-2023', index=False)
    # Get the worksheet object
    worksheet = writer.sheets['04-08-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'T':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\NextGen Claim Review 04-08-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\8\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-End-------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#









#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


habib_dups = pd.DataFrame()

# Assuming you have a DataFrame called 'habib_df'
habib_df['First Name (Billing)'] = habib_df['First Name (Billing)'].str.upper()
habib_df['Last Name (Billing)'] = habib_df['Last Name (Billing)'].str.upper()


habib_df['Order Date'] = pd.to_datetime(habib_df['Order Date']).dt.strftime('%m/%d/%Y')
habib_raw['Order Date'] = pd.to_datetime(habib_raw['Order Date']).dt.strftime('%m/%d/%Y')


habib_raw['Source'] = 'Habib'
habib_raw['Order Status'] = "InProcess"
habib_raw['Order Date'] = '04-08-2023'
habib_raw['Alpha Status'] = "Accepted"
habib_raw = habib_raw.drop('Recording Links', axis=1)
habib_raw['Processed Date'] = '04-09-2023'
habib_raw['Error'] = ""
habib_raw['Alpha Comment'] = ""
habib_raw['Recording Links'] = habib_df['Recording Links']


cleaned_df = habib_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
habib_cleaned_df = habib_df.copy()

# Assign the 'comment' column to the new dataframe
habib_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
habib_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

habib_df.iloc[:, 3] = habib_df.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 4] = habib_df.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 5] = habib_df.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 6] = habib_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 7] = habib_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 8] = habib_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
habib_df.iloc[:, 9] = habib_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 10] = habib_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 11] = habib_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
habib_df.iloc[:, 12] = habib_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


habib_raw.iloc[:, 3] = habib_raw.iloc[:, 3].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 4] = habib_raw.iloc[:, 4].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 5] = habib_raw.iloc[:, 5].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 6] = habib_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 7] = habib_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 8] = habib_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
habib_raw.iloc[:, 9] = habib_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 10] = habib_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 11] = habib_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
habib_raw.iloc[:, 12] = habib_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)



habib_df['DOB'] = pd.to_datetime(habib_df['DOB']).dt.strftime('%m/%d/%Y')
habib_raw['DOB'] = pd.to_datetime(habib_raw['DOB']).dt.strftime('%m/%d/%Y')


habib_dups = habib_df[habib_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not habib_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=habib_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in habib_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            habib_df = habib_df.drop(group.index[1:])
            habib_raw.loc[habib_dups.index,'Source'] = "Habib"
            habib_raw.loc[habib_dups.index,'Error'] = "Duplicate Medicare ID"
            habib_raw.loc[habib_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            habib_df = habib_df.drop(group.index)
            habib_raw.loc[habib_dups.index,'Source'] = "Habib"
            habib_raw.loc[habib_dups.index,'Error'] = "Duplicate Medicare ID"
            habib_raw.loc[habib_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    habib_df = pd.concat([habib_df, unique_records])
    habib_raw = pd.concat([habib_raw, unique_records])


habib_mid_matches = habib_df[habib_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not habib_mid_matches.empty:
    habib_raw.loc[habib_mid_matches.index, 'Alpha Status'] = "Rejected"
    habib_raw.loc[habib_mid_matches.index, 'Order Status'] = "Rejected"
    habib_raw.loc[habib_mid_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and MID List.")
    habib_df = habib_df.drop(habib_mid_matches.index)

habib_phone_matches = habib_df[habib_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not habib_phone_matches.empty:
    habib_raw.loc[habib_phone_matches.index, 'Alpha Status'] = "Rejected"
    habib_raw.loc[habib_phone_matches.index, 'Order Status'] = "Rejected"
    habib_raw.loc[habib_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")
    habib_df = habib_df.drop(habib_phone_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
habib_order_matches = habib_df[habib_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not habib_order_matches.empty:
    habib_raw.loc[habib_order_matches.index, 'Alpha Status'] = "Rejected"
    habib_raw.loc[habib_order_matches.index, 'Order Status'] = "Rejected"
    habib_raw.loc[habib_order_matches.index, 'Error'] = "MID matched with MASTER MID List"
    print("Found medicare matches in Habib and Master MID List.")
    habib_df = habib_df.drop(habib_order_matches.index)

last_order_number = (orderbatch_df['Order Number'].max() + 1)
end_num = last_order_number + len(habib_df)
habib_df['Order Number'] = list(range(last_order_number, end_num))
habib_df['Source'] = "Habib"
habib_df['Order Status'] = "InProcess"
habib_df['Alpha Status'] = "Accepted"
habib_df['Order Date'] = '04-08-2023'
orderbatch_df = pd.concat([orderbatch_df, habib_df], ignore_index=True)
with pd.ExcelWriter('Habib Claim Review 04-08-2023.xlsx') as writer:
    habib_raw.to_excel(writer, sheet_name='04-08-2023', index=False)
    worksheet = writer.sheets['04-08-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\Habib Claim Review 04-08-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\8\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#











"""
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------CPL---------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

cpl_dups = pd.DataFrame()

# Assuming you have a DataFrame called 'habib_df'
cpl_df['First Name (Billing)'] = cpl_df['First Name (Billing)'].str.upper()
cpl_df['Last Name (Billing)'] = cpl_df['Last Name (Billing)'].str.upper()


cpl_raw['Source'] = "CPL"
cpl_raw['Order Status'] = "InProcess"
cpl_raw['Order Date'] = '04-06-2023'
cpl_raw['Alpha Status'] = "Accepted"
cpl_raw = cpl_raw.drop('Recording Links', axis=1)
cpl_raw['Processed Date'] = '04-07-2023'
cpl_raw['Error'] = ""
cpl_raw['Alpha Comment'] = ""
cpl_raw['Recording Links'] = cpl_df['Recording Links']



cleaned_df = mitti_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']


# Assign the 'comment' column to the new dataframe
cpl_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

cpl_df.iloc[:, 3] = cpl_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 4] = cpl_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 5] = cpl_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 6] = cpl_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 7] = cpl_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 8] = cpl_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
cpl_df.iloc[:, 9] = cpl_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 10] = cpl_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 11] = cpl_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
cpl_df.iloc[:, 12] = cpl_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


cpl_raw.iloc[:, 3] = cpl_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 4] = cpl_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 5] = cpl_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 6] = cpl_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 7] = cpl_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 8] = cpl_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
cpl_raw.iloc[:, 9] = cpl_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 10] = cpl_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 11] = cpl_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
cpl_raw.iloc[:, 12] = cpl_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


cpl_df['DOB'] = pd.to_datetime(cpl_df['DOB']).dt.strftime('%m/%d/%Y')
cpl_raw['DOB'] = pd.to_datetime(cpl_raw['DOB']).dt.strftime('%m/%d/%Y')


cpl_dups = cpl_df[cpl_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not cpl_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=cpl_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in cpl_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            cpl_df = cpl_df.drop(group.index[1:])
            cpl_raw.loc[cpl_dups.index,'Source'] = "CPL"
            cpl_raw.loc[cpl_dups.index,'Error'] = "Duplicate Medicare ID"
            cpl_raw.loc[cpl_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            cpl_df = cpl_df.drop(group.index)
            cpl_raw.loc[cpl_dups.index,'Source'] = "CPL"
            cpl_raw.loc[cpl_dups.index,'Error'] = "Duplicate Medicare ID"
            cpl_raw.loc[cpl_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    cpl_df = pd.concat([cpl_df, unique_records])
    cpl_raw = pd.concat([cpl_raw, unique_records])


cpl_mid_matches = cpl_df[cpl_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not cpl_mid_matches.empty:
    cpl_raw.loc[cpl_mid_matches.index, 'Alpha Status'] = "Rejected"
    cpl_raw.loc[cpl_mid_matches.index, 'Order Status'] = "Rejected"
    cpl_raw.loc[cpl_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in CPL and DNC List.")
    cpl_df = cpl_df.drop(cpl_mid_matches.index)

cpl_phone_matches = cpl_df[cpl_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not cpl_phone_matches.empty:
    cpl_raw.loc[cpl_phone_matches.index, 'Alpha Status'] = "Rejected"
    cpl_raw.loc[cpl_phone_matches.index, 'Order Status'] = "Rejected"
    cpl_raw.loc[cpl_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in CPL and DNC List.")
    cpl_df = cpl_df.drop(cpl_phone_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
cpl_order_matches = cpl_df[cpl_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not cpl_order_matches.empty:
    cpl_raw.loc[cpl_order_matches.index, 'Alpha Status'] = "Rejected"
    cpl_raw.loc[cpl_order_matches.index, 'Order Status'] = "Rejected"
    cpl_raw.loc[cpl_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in CPL and DNC List.")
    cpl_df = cpl_df.drop(cpl_order_matches.index)

last_order_number = (orderbatch_df['Order Number'].max() + 1)
end_num = last_order_number + len(cpl_df)
cpl_df['Order Number'] = list(range(last_order_number, end_num))
cpl_df['Source'] = "CPL"
cpl_df['Order Status'] = "InProcess"
cpl_df['Order Date'] = '04-06-2023'
cpl_df['Alpha Status'] = "Accepted"
orderbatch_df = pd.concat([orderbatch_df, cpl_df], ignore_index=True)
with pd.ExcelWriter('CPL Claim Review 04-06-2023.xlsx') as writer:
    cpl_raw.to_excel(writer, sheet_name='04-06-2023', index=False)
    worksheet = writer.sheets['04-06-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\CPL Claim Review 04-06-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\6\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------CPL-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

"""









#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Mitti---------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

mitti_dups = pd.DataFrame()

# Assuming you have a DataFrame called 'habib_df'
mitti_df['First Name (Billing)'] = mitti_df['First Name (Billing)'].str.upper()
mitti_df['Last Name (Billing)'] = mitti_df['Last Name (Billing)'].str.upper()

mitti_raw['Source'] = "Mitti"
mitti_raw['Order Status'] = "InProcess"
mitti_raw['Order Date'] = '04-08-2023'
mitti_raw['Alpha Status'] = "Accepted"
mitti_raw = mitti_raw.drop('Recording Links', axis=1)
mitti_raw['Processed Date'] = '04-09-2023'
mitti_raw['Error'] = ""
mitti_raw['Alpha Comment'] = ""
mitti_raw['Recording Links'] = mitti_df['Recording Links']


cleaned_df = mitti_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
mitti_cleaned_df = mitti_df.copy()

# Assign the 'comment' column to the new dataframe
mitti_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
mitti_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

mitti_df.iloc[:, 3] = mitti_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 4] = mitti_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 5] = mitti_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 6] = mitti_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 7] = mitti_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 8] = mitti_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
mitti_df.iloc[:, 9] = mitti_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 10] = mitti_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 11] = mitti_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
mitti_df.iloc[:, 12] = mitti_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


mitti_raw.iloc[:, 3] = mitti_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 4] = mitti_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 5] = mitti_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 6] = mitti_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 7] = mitti_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 8] = mitti_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
mitti_raw.iloc[:, 9] = mitti_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 10] = mitti_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 11] = mitti_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
mitti_raw.iloc[:, 12] = mitti_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


mitti_df['DOB'] = pd.to_datetime(mitti_df['DOB']).dt.strftime('%m/%d/%Y')
mitti_raw['DOB'] = pd.to_datetime(mitti_raw['DOB']).dt.strftime('%m/%d/%Y')


mitti_dups = mitti_df[mitti_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not mitti_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=mitti_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in mitti_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            mitti_df = mitti_df.drop(group.index[1:])
            mitti_raw.loc[mitti_dups.index,'Source'] = "Mitti"
            mitti_raw.loc[mitti_dups.index,'Error'] = "Duplicate Medicare ID"
            mitti_raw.loc[mitti_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            mitti_df = mitti_df.drop(group.index)
            mitti_raw.loc[mitti_dups.index,'Source'] = "Mitti"
            mitti_raw.loc[mitti_dups.index,'Error'] = "Duplicate Medicare ID"
            mitti_raw.loc[mitti_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    mitti_df = pd.concat([mitti_df, unique_records])
    mitti_raw = pd.concat([mitti_raw, unique_records])


mitti_mid_matches = mitti_df[mitti_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not mitti_mid_matches.empty:
    mitti_raw.loc[mitti_mid_matches.index, 'Alpha Status'] = "Rejected"
    mitti_raw.loc[mitti_mid_matches.index, 'Order Status'] = "Rejected"
    mitti_raw.loc[mitti_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in Mitti and DNC List.")
    mitti_df = mitti_df.drop(mitti_mid_matches.index)

mitti_phone_matches = mitti_df[mitti_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not mitti_phone_matches.empty:
    mitti_raw.loc[mitti_phone_matches.index, 'Alpha Status'] = "Rejected"
    mitti_raw.loc[mitti_phone_matches.index, 'Order Status'] = "Rejected"
    mitti_raw.loc[mitti_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Mitti and DNC List.")
    mitti_df = mitti_df.drop(mitti_phone_matches.index)


orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
mitti_order_matches = mitti_df[mitti_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not mitti_order_matches.empty:
    mitti_raw.loc[mitti_order_matches.index, 'Alpha Status'] = "Rejected"
    mitti_raw.loc[mitti_order_matches.index, 'Order Status'] = "Rejected"
    mitti_raw.loc[mitti_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in Mitti and DNC List.")
    mitti_df = mitti_df.drop(mitti_order_matches.index)

last_order_number = (orderbatch_df['Order Number'].max() + 1)
end_num = last_order_number + len(mitti_df)
mitti_df['Order Number'] = list(range(last_order_number, end_num))
mitti_df['Source'] = "Mitti"
mitti_df['Order Status'] = "InProcess"
mitti_df['Order Date'] = '04-08-2023'
mitti_df['Alpha Status'] = "Accepted"
orderbatch_df = pd.concat([orderbatch_df, mitti_df], ignore_index=True)
with pd.ExcelWriter('Mitti Claim Review 04-08-2023.xlsx') as writer:
    mitti_raw.to_excel(writer, sheet_name='04-08-2023', index=False)
    worksheet = writer.sheets['04-08-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'T':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\Mitti Claim Review 04-08-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\8\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Mitti-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#









"""

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------7Tel--------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

seventel_dups = pd.DataFrame()

# Assuming you have a DataFrame called 'habib_df'
seventel_df['First Name (Billing)'] = seventel_df['First Name (Billing)'].str.upper()
seventel_df['Last Name (Billing)'] = seventel_df['Last Name (Billing)'].str.upper()

seventel_raw['Source'] = "7Tel"
seventel_raw['Order Status'] = "InProcess"
seventel_raw['Order Date'] = '04-07-2023'
seventel_raw['Alpha Status'] = "Accepted"
#seventel_raw = seventel_raw.drop('Recording Links', axis=1)
seventel_raw['Processed Date'] = '04-08-2023'
seventel_raw['Error'] = ""
seventel_raw['Alpha Comment'] = ""
#seventel_raw['Recording Links'] = seventel_df['Recording Links']


cleaned_df = seventel_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
seventel_cleaned_df = seventel_df.copy()

# Assign the 'comment' column to the new dataframe
seventel_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
seventel_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

seventel_df.iloc[:, 3] = seventel_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 4] = seventel_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 5] = seventel_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 6] = seventel_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 7] = seventel_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 8] = seventel_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
seventel_df.iloc[:, 9] = seventel_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 10] = seventel_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 11] = seventel_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
seventel_df.iloc[:, 12] = seventel_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


seventel_raw.iloc[:, 3] = seventel_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 4] = seventel_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 5] = seventel_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 6] = seventel_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 7] = seventel_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 8] = seventel_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
seventel_raw.iloc[:, 9] = seventel_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 10] = seventel_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 11] = seventel_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
seventel_raw.iloc[:, 12] = seventel_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


seventel_df['DOB'] = pd.to_datetime(seventel_df['DOB']).dt.strftime('%m/%d/%Y')
seventel_raw['DOB'] = pd.to_datetime(seventel_raw['DOB']).dt.strftime('%m/%d/%Y')

seventel_dups = seventel_df[seventel_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not seventel_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=seventel_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in seventel_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            seventel_df = seventel_df.drop(group.index[1:])
            seventel_raw.loc[seventel_dups.index,'Source'] = "7Tel"
            seventel_raw.loc[seventel_dups.index,'Error'] = "Duplicate Medicare ID"
            seventel_raw.loc[seventel_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            seventel_df = seventel_df.drop(group.index)
            seventel_raw.loc[seventel_dups.index,'Source'] = "7Tel"
            seventel_raw.loc[seventel_dups.index,'Error'] = "Duplicate Medicare ID"
            seventel_raw.loc[seventel_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    seventel_df = pd.concat([seventel_df, unique_records])
    seventel_raw = pd.concat([seventel_raw, unique_records])

seventel_mid_matches = seventel_df[seventel_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not seventel_mid_matches.empty:
    seventel_raw.loc[seventel_mid_matches.index, 'Alpha Status'] = "Rejected"
    seventel_raw.loc[seventel_mid_matches.index, 'Order Status'] = "Rejected"
    seventel_raw.loc[seventel_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in 7Tel and DNC List.")
    seventel_df = seventel_df.drop(seventel_mid_matches.index)

seventel_phone_matches = seventel_df[seventel_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not seventel_phone_matches.empty:
    seventel_raw.loc[seventel_phone_matches.index, 'Alpha Status'] = "Rejected"
    seventel_raw.loc[seventel_phone_matches.index, 'Order Status'] = "Rejected"
    seventel_raw.loc[seventel_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in 7Tel and DNC List.")
    seventel_df = seventel_df.drop(seventel_phone_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
seventel_order_matches = seventel_df[seventel_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not seventel_order_matches.empty:
    seventel_raw.loc[seventel_order_matches.index, 'Alpha Status'] = "Rejected"
    seventel_raw.loc[seventel_order_matches.index, 'Order Status'] = "Rejected"
    seventel_raw.loc[seventel_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in 7Tel and DNC List.")
    seventel_df = seventel_df.drop(seventel_order_matches.index)


last_order_number = (orderbatch_df['Order Number'].max() + 1)
end_num = last_order_number + len(seventel_df)
seventel_df['Order Number'] = list(range(last_order_number, end_num))
seventel_df['Source'] = "7Tel"
seventel_df['Order Status'] = "InProcess"
seventel_df['Order Date'] = '04-07-2023'
seventel_df['Alpha Status'] = "Accepted"
orderbatch_df = pd.concat([orderbatch_df, seventel_df], ignore_index=True)
with pd.ExcelWriter('7Tel Claim Review 04-07-2023.xlsx') as writer:
    seventel_raw.to_excel(writer, sheet_name='04-07-2023', index=False)
    worksheet = writer.sheets['04-07-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20


shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\7Tel Claim Review 04-07-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\7\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------7Tel-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

"""












#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------P1----------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

p1_dups = pd.DataFrame()

# Assuming you have a DataFrame called 'habib_df'
p1_df['First Name (Billing)'] = p1_df['First Name (Billing)'].str.upper()
p1_df['Last Name (Billing)'] = p1_df['Last Name (Billing)'].str.upper()

p1_raw['Source'] = "P1"
p1_raw['Order Status'] = "InProcess"
p1_raw['Order Date'] = '04-08-2023'
p1_raw['Alpha Status'] = "Accepted"
p1_raw = p1_raw.drop('Recording Links', axis=1)
p1_raw['Processed Date'] = '04-09-2023'
p1_raw['Error'] = ""
p1_raw['Alpha Comment'] = ""
p1_raw['Recording Links'] = p1_df['Recording Links']


cleaned_df = p1_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Make a copy of the original dataframe
p1_cleaned_df = p1_df.copy()

# Assign the 'comment' column to the new dataframe
p1_cleaned_df['Alpha Comment'] = cleaned_df['Alpha Comment']
p1_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

p1_df.iloc[:, 3] = p1_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 4] = p1_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 5] = p1_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 6] = p1_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 7] = p1_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 8] = p1_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
p1_df.iloc[:, 9] = p1_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 10] = p1_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 11] = p1_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
p1_df.iloc[:, 12] = p1_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


p1_raw.iloc[:, 3] = p1_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 4] = p1_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 5] = p1_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 6] = p1_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 7] = p1_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 8] = p1_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
p1_raw.iloc[:, 9] = p1_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 10] = p1_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 11] = p1_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
p1_raw.iloc[:, 12] = p1_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


p1_df['DOB'] = pd.to_datetime(p1_df['DOB']).dt.strftime('%m/%d/%Y')
p1_raw['DOB'] = pd.to_datetime(p1_raw['DOB']).dt.strftime('%m/%d/%Y')

p1_dups = p1_df[p1_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not p1_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=p1_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in p1_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            p1_df = p1_df.drop(group.index[1:])
            p1_raw.loc[p1_dups.index,'Source'] = "P1"
            p1_raw.loc[p1_dups.index,'Error'] = "Duplicate Medicare ID"
            p1_raw.loc[p1_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            p1_df = p1_df.drop(group.index)
            p1_raw.loc[p1_dups.index,'Source'] = "P1"
            p1_raw.loc[p1_dups.index,'Error'] = "Duplicate Medicare ID"
            p1_raw.loc[p1_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    p1_df = pd.concat([p1_df, unique_records])
    p1_raw = pd.concat([p1_raw, unique_records])

p1_mid_matches = p1_df[p1_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not p1_mid_matches.empty:
    p1_raw.loc[p1_mid_matches.index, 'Alpha Status'] = "Rejected"
    p1_raw.loc[p1_mid_matches.index, 'Order Status'] = "Rejected"
    p1_raw.loc[p1_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in P1 and DNC List.")
    p1_df = p1_df.drop(p1_mid_matches.index)

p1_phone_matches = p1_df[p1_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not p1_phone_matches.empty:
    p1_raw.loc[p1_phone_matches.index, 'Alpha Status'] = "Rejected"
    p1_raw.loc[p1_phone_matches.index, 'Order Status'] = "Rejected"
    p1_raw.loc[p1_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in P1 and DNC List.")
    p1_df = p1_df.drop(p1_phone_matches.index)

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
p1_order_matches = p1_df[p1_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not p1_order_matches.empty:
    p1_raw.loc[p1_order_matches.index, 'Alpha Status'] = "Rejected"
    p1_raw.loc[p1_order_matches.index, 'Order Status'] = "Rejected"
    p1_raw.loc[p1_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in P1 and DNC List.")
    p1_df = p1_df.drop(p1_order_matches.index)

last_order_number = (orderbatch_df['Order Number'].max() + 1)
end_num = last_order_number + len(p1_df)
p1_df['Order Number'] = list(range(last_order_number, end_num))
p1_df['Source'] = "P1"
p1_df['Order Status'] = "InProcess"
p1_df['Order Date'] = '04-08-2023'
p1_df['Alpha Status'] = "Accepted"
orderbatch_df = pd.concat([orderbatch_df, p1_df], ignore_index=True)
with pd.ExcelWriter('P1 Claim Review 04-08-2023.xlsx') as writer:
    p1_raw.to_excel(writer, sheet_name='04-08-2023', index=False)
    worksheet = writer.sheets['04-08-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'T':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 20

shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\P1 Claim Review 04-08-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\8\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------P1-End------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#












#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------BlueBells----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

bluebells_dups = pd.DataFrame()

# Assuming you have a DataFrame called 'habib_df'
bluebells_df['First Name (Billing)'] = bluebells_df['First Name (Billing)'].str.upper()
bluebells_df['Last Name (Billing)'] = bluebells_df['Last Name (Billing)'].str.upper()

bluebells_raw['Source'] = "BlueBells"
bluebells_raw['Order Status'] = "InProcess"
bluebells_raw['Order Date'] = '04-07-2023'
bluebells_raw['Alpha Status'] = "Accepted"
bluebells_raw = bluebells_raw.drop('Recording Links', axis=1)
bluebells_raw['Processed Date'] = '04-09-2023'
bluebells_raw['Error'] = ""
bluebells_raw['Alpha Comment'] = ""
bluebells_raw['Recording Links'] = bluebells_df['Recording Links']


cleaned_df = bluebells_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Assign the 'comment' column to the new dataframe
bluebells_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

bluebells_df.iloc[:, 3] = bluebells_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 4] = bluebells_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 5] = bluebells_df.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 6] = bluebells_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 7] = bluebells_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 8] = bluebells_df.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
bluebells_df.iloc[:, 9] = bluebells_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 10] = bluebells_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 11] = bluebells_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_df.iloc[:, 12] = bluebells_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


bluebells_raw.iloc[:, 3] = bluebells_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 4] = bluebells_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 5] = bluebells_raw.iloc[:, 5].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 6] = bluebells_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 7] = bluebells_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 8] = bluebells_raw.iloc[:, 8].str.replace('[^0-9A-Za-z ]', '', regex=True)
bluebells_raw.iloc[:, 9] = bluebells_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 10] = bluebells_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 11] = bluebells_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
bluebells_raw.iloc[:, 12] = bluebells_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


bluebells_df['DOB'] = pd.to_datetime(bluebells_df['DOB']).dt.strftime('%m/%d/%Y')
bluebells_raw['DOB'] = pd.to_datetime(bluebells_raw['DOB']).dt.strftime('%m/%d/%Y')

bluebells_dups = bluebells_df[bluebells_df.duplicated(subset=['MedicareNumber', 'First Name (Billing)', 'Last Name (Billing)'], keep= False)]
if not bluebells_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=bluebells_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in bluebells_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            bluebells_df = bluebells_df.drop(group.index[1:])
            bluebells_raw.loc[bluebells_dups.index,'Source'] = "BlueBells"
            bluebells_raw.loc[bluebells_dups.index,'Error'] = "Duplicate Medicare ID"
            bluebells_raw.loc[bluebells_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            bluebells_df = bluebells_df.drop(group.index)
            bluebells_raw.loc[bluebells_dups.index,'Source'] = "BlueBells"
            bluebells_raw.loc[bluebells_dups.index,'Error'] = "Duplicate Medicare ID"
            bluebells_raw.loc[bluebells_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    bluebells_df = pd.concat([bluebells_df, unique_records])
    bluebells_raw = pd.concat([bluebells_raw, unique_records])



bluebells_mid_matches = bluebells_df[bluebells_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not bluebells_mid_matches.empty:
    bluebells_raw.loc[bluebells_mid_matches.index, 'Alpha Status'] = "Rejected"
    bluebells_raw.loc[bluebells_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in BlueBells and DNC List.")
    bluebells_df = bluebells_df.drop(bluebells_mid_matches.index)


bluebells_phone_matches = bluebells_df[bluebells_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not bluebells_phone_matches.empty:
    bluebells_raw.loc[bluebells_phone_matches.index, 'Alpha Status'] = "Rejected"
    bluebells_raw.loc[bluebells_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in BlueBells and DNC List.")
    bluebells_df = bluebells_df.drop(bluebells_phone_matches.index)

bluebells_order_matches = bluebells_df[bluebells_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not bluebells_order_matches.empty:
    bluebells_raw.loc[bluebells_order_matches.index, 'Alpha Status'] = "Rejected"
    bluebells_raw.loc[bluebells_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in BlueBells and DNC List.")
    bluebells_df = bluebells_df.drop(bluebells_order_matches.index)

last_order_number = (orderbatch_df['Order Number'].max() + 1)
end_num = last_order_number + len(bluebells_df)
bluebells_df['Order Number'] = list(range(last_order_number, end_num))
bluebells_df['Source'] = "BlueBells"
bluebells_df['Order Status'] = "InProcess"
bluebells_df['Order Date'] = '04-07-2023'
bluebells_df['Alpha Status'] = "Accepted"
orderbatch_df = pd.concat([orderbatch_df, bluebells_df], ignore_index=True)
with pd.ExcelWriter('BlueBells Claim Review 04-07-2023.xlsx') as writer:
    bluebells_raw.to_excel(writer, sheet_name='04-07-2023', index=False)
    worksheet = writer.sheets['04-07-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 15

shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\BlueBells Claim Review 04-07-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\8\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------BlueBell-End------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#











"""
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Amigos----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

amigos_dups = pd.DataFrame()

amigos_raw['Source'] = "Amigos"
amigos_raw['Order Status'] = "InProcess"
amigos_raw['Order Date'] = '03-31-2023'
amigos_raw['Error'] = ''
amigos_raw['Alpha Status'] = "Accepted"


cleaned_df = amigos_df.iloc[:, columns_to_clean].apply(clean_row, axis=1, result_type='expand')
cleaned_df.columns = [f"col{i+1}" for i in range(cleaned_df.shape[1]-1)] + ['Alpha Comment']

# Assign the 'comment' column to the new dataframe
amigos_raw['Alpha Comment'] = cleaned_df['Alpha Comment']

amigos_df.iloc[:, 3] = amigos_df.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 4] = amigos_df.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 6] = amigos_df.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 7] = amigos_df.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 8] = amigos_df.iloc[:, 8].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 9] = amigos_df.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 10] = amigos_df.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 11] = amigos_df.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
amigos_df.iloc[:, 12] = amigos_df.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


amigos_raw.iloc[:, 3] = amigos_raw.iloc[:, 3].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 4] = amigos_raw.iloc[:, 4].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 6] = amigos_raw.iloc[:, 6].replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 7] = amigos_raw.iloc[:, 7].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 8] = amigos_raw.iloc[:, 8].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 9] = amigos_raw.iloc[:, 9].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 10] = amigos_raw.iloc[:, 10].str.replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 11] = amigos_raw.iloc[:, 11].replace('[^0-9A-Za-z]', '', regex=True)
amigos_raw.iloc[:, 12] = amigos_raw.iloc[:, 12].replace('[^0-9A-Za-z]', '', regex=True)


amigos_df['DOB'] = pd.to_datetime(amigos_df['DOB']).dt.strftime('%m/%d/%Y')
amigos_raw['DOB'] = pd.to_datetime(amigos_raw['DOB']).dt.strftime('%m/%d/%Y')

amigos_dups = amigos_df[amigos_df.duplicated(subset=['MedicareNumber', 'First Name (Billing)', 'Last Name (Billing)'], keep= False)]
if not amigos_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=amigos_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in amigos_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            amigos_df = amigos_df.drop(group.index[1:])
            amigos_raw.loc[amigos_dups.index,'Source'] = "BlueBells"
            amigos_raw.loc[amigos_dups.index,'Error'] = "Duplicate Medicare ID"
            amigos_raw.loc[amigos_dups.index,'Alpha Status'] = "Duplicate"
        else:
            # If not, delete all records in the group
            amigos_df = amigos_df.drop(group.index)
            amigos_raw.loc[amigos_dups.index,'Source'] = "BlueBells"
            amigos_raw.loc[amigos_dups.index,'Error'] = "Duplicate Medicare ID"
            amigos_raw.loc[amigos_dups.index,'Alpha Status'] = "Duplicate"

    # Append the unique records to the original dataframe
    amigos_df = pd.concat([amigos_df, unique_records])
    amigos_raw = pd.concat([amigos_raw, unique_records])



amigos_mid_matches = amigos_df[amigos_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not amigos_mid_matches.empty:
    amigos_raw.loc[amigos_mid_matches.index, 'Alpha Status'] = "Rejected"
    amigos_raw.loc[amigos_mid_matches.index, 'Error'] = "Medicare matched with MID List"
    print("Found phone matches in Habib and DNC List.")
    amigos_df = amigos_df.drop(amigos_mid_matches.index)


amigos_phone_matches = amigos_df[amigos_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not amigos_phone_matches.empty:
    amigos_raw.loc[amigos_phone_matches.index, 'Alpha Status'] = "Rejected"
    amigos_raw.loc[amigos_phone_matches.index, 'Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")
    amigos_df = amigos_df.drop(amigos_phone_matches.index)

amigos_order_matches = amigos_df[amigos_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not amigos_order_matches.empty:
    amigos_raw.loc[amigos_order_matches.index, 'Alpha Status'] = "Rejected"
    amigos_raw.loc[amigos_order_matches.index, 'Error'] = "Medicare matched with Master MID List"
    print("Found phone matches in Habib and DNC List.")
    amigos_df = amigos_df.drop(amigos_order_matches.index)

last_order_number = (orderbatch_df['Order Number'].max() + 1)
end_num = last_order_number + len(amigos_df)
amigos_df['Order Number'] = list(range(last_order_number, end_num))
amigos_df['Source'] = "Amigos"
amigos_df['Order Status'] = "InProcess"
amigos_df['Order Date'] = '03-31-2023'
amigos_df['Alpha Status'] = "Accepted"
orderbatch_df = orderbatch_df.append(amigos_df, ignore_index = True)
with pd.ExcelWriter('Amigos Claim Review.xlsx') as writer:
    amigos_raw.to_excel(writer, sheet_name='03-31-2023', index=False)
    worksheet = writer.sheets['03-31-2023']
    # Set the width of column A to 20
    for col in worksheet.columns:
        col_letter = col[0].column_letter
        if col_letter >= 'A' and col_letter <= 'Q':
            col_dimensions = worksheet.column_dimensions[col_letter]
            col_dimensions.width = 15

shutil.move("C:\\AlphaData\\PREP\\Amigos Claim Review.xlsx","C:\\AlphaData\\PREP\\March\\31\\")

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Amigos-End------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
"""


orderbatch_df = orderbatch_df.drop('Recording Links',axis=1)
orderbatch_df['Processed Date'] = '04-09-2023'

with pd.ExcelWriter('OTC Claim Order 04-08-2023.xlsx') as writer2:
    orderbatch_df.to_excel(writer2, sheet_name='04-08-2023', index=False)
    worksheet2 = writer2.sheets['04-08-2023']
    for col in worksheet2.columns:
            col_letter = col[0].column_letter
            if col_letter >= 'A' and col_letter <= 'O':
                col_dimensions = worksheet2.column_dimensions[col_letter]
                col_dimensions.width = 20
shutil.move("C:\\Users\\Nakib\\Downloads\\PREP\\OTC Claim Order 04-08-2023.xlsx","C:\\Users\\Nakib\\Downloads\\PREP\\April\\8\\")
