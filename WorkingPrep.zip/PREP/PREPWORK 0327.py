import pandas as pd
import datetime

# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers.xlsx')
mid_df = pd.read_excel('Used MIDs.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= 'Sheet1')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= 'Sheet1')
habib_df = pd.read_excel('Habib.xlsx', sheet_name= 'Sheet1')

nextgen_duplicate_df = pd.DataFrame()
mitti_duplicate_df = pd.DataFrame()
habib_duplicate_df = pd.DataFrame()

now = datetime.datetime.now()






#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 10] = nextgen_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 11] = nextgen_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 12] = nextgen_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

nextgen_df['DOB'] = pd.to_datetime(nextgen_df['DOB']).dt.strftime('%m/%d/%Y')


duplicates_nextgen = nextgen_df[nextgen_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not duplicates_nextgen.empty:
    for _, row in duplicates_nextgen.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_nextgen)
    nextgen_df = nextgen_df.drop_duplicates(subset=[4], keep="first")
else:
    print("No Duplicates Found!")
#to do: check to make sure duplicate are the same people, if so then delete, if not reject both.

# Merge the data frames based on the phone number column
merged_nextgen_dnc = pd.merge(nextgen_df, dnc_df, how='inner', left_on='Phone (Billing)', right_on='phone')
# Get the indexes of the rows that match
matching_dncn_indexes = merged_nextgen_dnc.index
if not matching_dncn_indexes.empty:
    for _, row in matching_dncn_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the DNC List"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
nextgen_df = nextgen_df.drop(matching_dncn_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
dnc_df = pd.concat([dnc_df, merged_nextgen_dnc])

nextgen_df.to_excel('NextGen.xlsx', index=False)
nextgen_df = pd.read_excel('NextGen.xlsx')


# Merge the data frames based on the phone number column
merged_nextgen_mid = pd.merge(nextgen_df, mid_df, how='inner',left_on='MedicareNumber',right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midn_indexes = merged_nextgen_mid.index
if not matching_midn_indexes.empty:
    for _, row in matching_midn_indexes.iterrows():
        # create an error message
        error_msg = "Matched with the MID List"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
nextgen_df = nextgen_df.drop(matching_midn_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame
mid_df = pd.concat([mid_df, merged_nextgen_mid])

nextgen_df.to_excel('NextGen.xlsx', index=False)
nextgen_df = pd.read_excel('NextGen.xlsx')


#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
order_df = pd.DataFrame(columns=['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB', 'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source'])
# Append the data from the nextgen_df dataframe to the order_df dataframe
nextgen_order_df = nextgen_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
nextgen_order_df['Source'] = "NextGen" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
nextgen_order_df['Order Status'] = "In Process"
nextgen_order_df['Order Date'] = now.strftime('%m/%d/%Y')
nextgen_order_df['Order Number'] = 40000000
nextgen_order_df['Order Number'] = nextgen_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(nextgen_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index=False, header = True)
order_df = pd.read_excel('OrderBatch.xlsx')
nextgen_duplicate_df.to_excel('NextGen_Completed.xlsx', index=False)


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------NEXTGEN-END-------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


















#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------HABIB------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



habib_df.iloc[:, 3] = habib_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 4] = habib_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 5] = habib_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 6] = habib_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 7] = habib_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 8] = habib_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
habib_df.iloc[:, 9] = habib_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 10] = habib_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 11] = habib_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 12] = habib_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

habib_df['DOB'] = pd.to_datetime(habib_df['DOB']).dt.strftime('%m/%d/%Y')

duplicates_habib = habib_df[habib_df.duplicated(subset=['MedicareNumber'])]
if not duplicates_habib.empty:
    for _, row in duplicates_habib.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'Habib'
        # append the duplicate record to duplicate_df
        habib_duplicate_df = habib_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_habib)
    habib_df = habib_df.drop_duplicates(subset=[7], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_habib_dnc = pd.merge(habib_df, dnc_df, how='inner', left_on='Phone (Billing)', right_on='phone')
# Get the indexes of the rows that match
matching_dnch_indexes = merged_habib_dnc.index
for index in matching_dnch_indexes:
    row = merged_habib_dnc.loc[index]
    # create an error message
    error_msg = "Matched with the DNC List!"
    # add the error message to the duplicate record
    row['Error'] = error_msg
    row['Source'] = 'Habib'
    # append the duplicate record to duplicate_df
    habib_duplicate_df = habib_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
habib_df = habib_df.drop(matching_dnch_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame

habib_df.to_excel('Habib.xlsx', index=False)
habib_df = pd.read_excel('Habib.xlsx')


# Merge the data frames based on the phone number column
habib_df = habib_df.reset_index(drop=True)
merged_habib_mid = pd.merge(habib_df, mid_df, how='inner', left_on='MedicareNumber', right_on='MEDICARENUMBER')

# Get the indexes of the rows that match
matching_midh_indexes = merged_habib_mid.index
for index in matching_midh_indexes:
    row = merged_habib_mid.loc[index]
    # create an error message
    error_msg = "Matched with the MID List!"
    # add the error message to the duplicate record
    row['Error'] = error_msg
    row['Source'] = 'Habib'
    # append the duplicate record to duplicate_df
    habib_duplicate_df = habib_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
habib_df = habib_df.drop(matching_midh_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame

habib_df.to_excel('Habib.xlsx', index=False)
habib_df = pd.read_excel('Habib.xlsx')

habib_df = habib_df.reset_index(drop=True)
merged_habib_order_mid = pd.merge(habib_df, order_df, how='inner',left_on='MedicareNumber',right_on='MedicareNumber')
matching_mid_habib_order_indexes = merged_habib_order_mid.index
for index in matching_mid_habib_order_indexes:
    row = merged_habib_order_mid.loc[index]
    # create an error message
    error_msg = "Master Duplicate on MID!"
    # add the error message to the duplicate record
    row['Error'] = error_msg
    row['Source'] = 'Habib'
    # append the duplicate record to duplicate_df
    habib_duplicate_df = habib_duplicate_df.append(row)
habib_df = habib_df.drop(matching_mid_habib_order_indexes)
mid_df = pd.concat([mid_df, merged_habib_order_mid])

habib_df.to_excel('Habib.xlsx', index=False)
habib_df = pd.read_excel('Habib.xlsx')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

column_names = ['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB', 'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source']
habib_df = habib_df.reindex(columns=column_names)
# Append the data from the nextgen_df dataframe to the order_df dataframe
habib_order_df = habib_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
habib_order_df['Source'] = "Habib" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
habib_order_df['Order Status'] = "In Process"
habib_order_df['Order Date'] = now.strftime('%m/%d/%Y')
habib_order_df['Order Number'] = habib_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(habib_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')
habib_duplicate_df.to_excel('Habib_Completed.xlsx', index=False)

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------HABIB-END-------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

















#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#----------------------------------------------------------------------------------MITTI------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



mitti_df.iloc[:, 3] = mitti_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 4] = mitti_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 5] = mitti_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 6] = mitti_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 7] = mitti_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 8] = mitti_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
mitti_df.iloc[:, 9] = mitti_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 10] = mitti_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 11] = mitti_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 12] = mitti_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

mitti_df['DOB'] = pd.to_datetime(mitti_df['DOB']).dt.strftime('%m/%d/%Y')

duplicates_mitti = mitti_df[mitti_df.duplicated(subset=['MedicareNumber'])]
if not duplicates_mitti.empty:
    for _, row in duplicates_mitti.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'Mitti'
        # append the duplicate record to duplicate_df
        mitti_duplicate_df = mitti_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_mitti)
    mitti_df = mitti_df.drop_duplicates(subset=[7], keep="first")
else:
    print("No Duplicates Found!")

# Merge the data frames based on the phone number column
merged_mitti_dnc = pd.merge(mitti_df, dnc_df, how='inner', left_on='Phone (Billing)', right_on='phone')
# Get the indexes of the rows that match
matching_dncm_indexes = merged_mitti_dnc.index
for index in matching_dncm_indexes:
    row = merged_mitti_dnc.loc[index]
    # create an error message
    error_msg = "Matched with the DNC List!"
    # add the error message to the duplicate record
    row['Error'] = error_msg
    row['Source'] = 'Mitti'
    # append the duplicate record to duplicate_df
    mitti_duplicate_df = mitti_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
mitti_df = mitti_df.drop(matching_dncm_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')


# Merge the data frames based on the phone number column
merged_mitti_mid = pd.merge(mitti_df, mid_df, how='inner', left_on='MedicareNumber', right_on='MEDICARENUMBER')
# Get the indexes of the rows that match
matching_midm_indexes = merged_mitti_mid.index
for index in matching_midm_indexes:
    row = merged_mitti_mid.loc[index]
    # create an error message
    error_msg = "Matched with the MID List!"
    # add the error message to the duplicate record
    row['Error'] = error_msg
    row['Source'] = 'Mitti'
    # append the duplicate record to duplicate_df
    mitti_duplicate_df = mitti_duplicate_df.append(row)
# Drop the rows that match from the "mitti" data frame
mitti_df = mitti_df.drop(matching_midm_indexes)
# Append the remaining rows to the "Used Phone Numbers" data frame

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')

mitti_df = mitti_df.reset_index(drop=True)
merged_mitti_order_mid = pd.merge(mitti_df, order_df, how='inner',left_on='MedicareNumber',right_on='MedicareNumber')
matching_mid_mitti_order_indexes = merged_mitti_order_mid.index
for index in matching_mid_mitti_order_indexes:
    row = merged_mitti_order_mid.loc[index]
    # create an error message
    error_msg = "Master Duplicate on MID!"
    # add the error message to the duplicate record
    row['Error'] = error_msg
    row['Source'] = 'Mitti'
    # append the duplicate record to duplicate_df
    mitti_duplicate_df = mitti_duplicate_df.append(row)
mitti_df = mitti_df.drop(matching_mid_mitti_order_indexes)
mid_df = pd.concat([mid_df, merged_mitti_order_mid])

mitti_df.to_excel('Mitti.xlsx', index=False)
mitti_df = pd.read_excel('Mitti.xlsx')


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

mitti_df = mitti_df.reindex(columns=column_names)
# Append the data from the nextgen_df dataframe to the order_df dataframe
mitti_order_df = mitti_df.copy() # create a copy of the nextgen_df dataframe to avoid modifying the original dataframe
mitti_order_df['Source'] = "Mitti" # add a 'Source' column to the nextgen_order_df dataframe and set the value to 'NextGen'
mitti_order_df['Order Status'] = "In Process"
mitti_order_df['Order Date'] = now.strftime('%m/%d/%Y')
mitti_order_df['Order Number'] = mitti_order_df['Order Number'].apply(lambda x: x + 1)
order_df = order_df.append(mitti_order_df, ignore_index=True)
order_df.to_excel('OrderBatch.xlsx', index= False)
order_df = pd.read_excel('OrderBatch.xlsx')
mitti_duplicate_df.to_excel('Mitti_Completed.xlsx', index=False)

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------MITTI-END-------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#