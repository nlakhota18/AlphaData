import pandas as pd
import datetime

# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers.xlsx')
mid_df = pd.read_excel('Used MIDs.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= '03-27-2023')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '03-27-2023')
habib_df = pd.read_excel('Habib.xlsx', sheet_name= '03-27-2023')



nextgen_duplicate_df = pd.DataFrame()
mitti_duplicate_df = pd.DataFrame()
habib_duplicate_df = pd.DataFrame()



now = datetime.datetime.now()


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 10] = nextgen_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 11] = nextgen_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 12] = nextgen_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

nextgen_df['DOB'] = pd.to_datetime(nextgen_df['DOB']).dt.strftime('%m/%d/%Y')


duplicates_nextgen = nextgen_df[nextgen_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not duplicates_nextgen.empty:
    for _, row in duplicates_nextgen.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        nextgen_duplicate_df = nextgen_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_nextgen)
    nextgen_df = nextgen_df.drop_duplicates(subset=[7], keep="first")
else:
    print("No Duplicates Found!")
#to do: check to make sure duplicate are the same people, if so then delete, if not reject both.
nextgen_dups = pd.DataFrame()
nextgen_df['Phone (Billing)'] = nextgen_df['Phone (Billing)'].astype(str)
nextgen_phone_matches = nextgen_df[nextgen_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not nextgen_phone_matches.empty:
    nextgen_df = nextgen_df.drop(nextgen_phone_matches.index)
    nextgen_dups = pd.concat([nextgen_dups, nextgen_phone_matches])
    nextgen_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in NextGen and DNC.")

nextgen_mid_matches = nextgen_df[nextgen_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not nextgen_mid_matches.empty:
    nextgen_df = nextgen_df.drop(nextgen_mid_matches.index)
    nextgen_dups = pd.concat([nextgen_dups, nextgen_mid_matches])
    nextgen_dups['Error'] = "Phone Number matched with MID List"
    print("Found phone matches in NextGen and MID.")

orderbatch_df = pd.DataFrame(columns=['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB',
                                       'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source'])
start_order_number = 40000000
nextgen_df['Source'] = "NextGen"
nextgen_df['Order Status'] = "In Process"
nextgen_df['Order Number'] = start_order_number + nextgen_df.groupby(level=0).cumcount()
nextgen_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(nextgen_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
orderbatch_df = pd.read_excel('OrderBatch.xlsx')
nextgen_dups.to_excel('NextGen Completed.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-End-------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#









#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



habib_df.iloc[:, 3] = habib_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 4] = habib_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 5] = habib_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 6] = habib_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 7] = habib_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 8] = habib_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
habib_df.iloc[:, 9] = habib_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 10] = habib_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 11] = habib_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 12] = habib_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

habib_df['DOB'] = pd.to_datetime(habib_df['DOB']).dt.strftime('%m/%d/%Y')


duplicates_habib = habib_df[habib_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not duplicates_habib.empty:
    for _, row in duplicates_habib.iterrows():
        # create an error message
        error_msg = "Duplicate Medicare Number!"
        # add the error message to the duplicate record
        row['Error'] = error_msg
        row['Source'] = 'NextGen'
        # append the duplicate record to duplicate_df
        habib_duplicate_df = habib_duplicate_df.append(row)
    print("Found duplicate values in MBI:\n", duplicates_habib)
    habib_df = habib_df.drop_duplicates(subset=[7], keep="first")
else:
    print("No Duplicates Found!")
#to do: check to make sure duplicate are the same people, if so then delete, if not reject both.
habib_dups = pd.DataFrame()
habib_phone_matches = habib_df[habib_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not habib_phone_matches.empty:
    habib_df = habib_df.drop(habib_phone_matches.index)
    habib_dups = pd.concat([habib_dups, habib_phone_matches])
    habib_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC.")

habib_mid_matches = habib_df[habib_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not habib_mid_matches.empty:
    habib_df = habib_df.drop(habib_mid_matches.index)
    habib_dups = pd.concat([habib_dups, habib_mid_matches])
    habib_dups['Error'] = "Medicare # matched with MID List"
    print("Found medicare matches in Habib and MID.")

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
habib_order_matches = habib_df[habib_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not habib_order_matches.empty:
    habib_df = habib_df.drop(habib_order_matches.index)
    habib_dups = pd.concat([habib_dups, habib_order_matches])
    habib_dups['Error'] = "Phone Number matched with MID List"
    print("Found medicare matches in Habib and MID.")

last_order_number = orderbatch_df['Order Number'].iloc[-1]
habib_df['Source'] = "Habib"
habib_df['Order Status'] = "InProcess"
habib_df['Order Date'] = now.strftime('%m/%d/%Y')
habib_df['Order Number'] = last_order_number + habib_df.groupby(level=0).cumcount()
orderbatch_df = orderbatch_df.append(habib_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
habib_dups.to_excel('Habib Completed.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
