import pandas as pd
import datetime
import re

# Load the data from the Excel files into data frames
dnc_df = pd.read_excel('Used Phone Numbers.xlsx')
mid_df = pd.read_excel('Used MIDs.xlsx')
mitti_df = pd.read_excel('Mitti.xlsx', sheet_name= '03-28-2023')
nextgen_df = pd.read_excel('NextGen.xlsx', sheet_name= '03-28-2023')
habib_df = pd.read_excel('Habib.xlsx', sheet_name= '03-28-2023')
cpl_df = pd.read_excel('CPL.xlsx', sheet_name= '03-28-2023')
seventel_df = pd.read_excel('7Tel.xlsx', sheet_name= '03-28-2023')



nextgen_duplicate_df = pd.DataFrame()
mitti_duplicate_df = pd.DataFrame()
habib_duplicate_df = pd.DataFrame()
cpl_duplicate_df = pd.DataFrame()
seventel_duplicate_df = pd.DataFrame()




now = datetime.datetime.now()


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

nextgen_df.iloc[:, 3] = nextgen_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 4] = nextgen_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 5] = nextgen_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 6] = nextgen_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 7] = nextgen_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 8] = nextgen_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
nextgen_df.iloc[:, 9] = nextgen_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 10] = nextgen_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 11] = nextgen_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
nextgen_df.iloc[:, 12] = nextgen_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

nextgen_df['DOB'] = pd.to_datetime(nextgen_df['DOB']).dt.strftime('%m/%d/%Y')


# Merge the cleaned columns back into the original dataframe
nextgen_dups = pd.DataFrame()

nextgen_dups = nextgen_df[nextgen_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not nextgen_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=nextgen_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in nextgen_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            unique_records = unique_records.append(group.iloc[0], ignore_index=True)
        else:
            # If not, delete all records in the group
            nextgen_dups = nextgen_dups.drop(group.index)
    
    # Append the unique records to the original dataframe
    seventel_df = pd.concat([seventel_df, unique_records])
    
if not nextgen_dups.empty:
    # Add error message to the duplicate records
    nextgen_dups['Error'] = "Duplicate Medicare Number!"
    nextgen_dups['Source'] = '7Tel'
    print("Found duplicate values in MBI:\n", nextgen_dups)


nextgen_df['Phone (Billing)'] = nextgen_df['Phone (Billing)'].astype(str)
nextgen_phone_matches = nextgen_df[nextgen_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not nextgen_phone_matches.empty:
    nextgen_df = nextgen_df.drop(nextgen_phone_matches.index)
    nextgen_dups = pd.concat([nextgen_dups, nextgen_phone_matches])
    nextgen_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in NextGen and DNC List.")

nextgen_mid_matches = nextgen_df[nextgen_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not nextgen_mid_matches.empty:
    nextgen_df = nextgen_df.drop(nextgen_mid_matches.index)
    nextgen_dups = pd.concat([nextgen_dups, nextgen_mid_matches])
    nextgen_dups['Error'] = "Medicare Number matched with MID List"
    print("Found phone matches in NextGen and MID List.")

orderbatch_df = pd.DataFrame(columns=['Order Status','Order Number','Order Date','Last Name (Billing)', 'First Name (Billing)', 'Gender', 'DOB',
                                       'MedicareNumber', 'Address 1&2 (Billing)', 'City (Billing)', 'State Code (Billing)', 'Postcode (Billing)', 'Phone (Billing)', 'Source', 'Alpha Status', 'Alpha Comment'])
start_num = 40000000
end_num = start_num + len(nextgen_df)
nextgen_df['Source'] = "NextGen"
nextgen_df['Order Status'] = "In Process"
nextgen_df['Order Number'] = list(range(start_num, end_num))
nextgen_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(nextgen_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
orderbatch_df = pd.read_excel('OrderBatch.xlsx')
nextgen_dups.to_excel('NextGen Completed.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------NextGen-End-------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#









#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#


habib_df.iloc[:, 3] = habib_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 4] = habib_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 5] = habib_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 6] = habib_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 7] = habib_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 8] = habib_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
habib_df.iloc[:, 9] = habib_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 10] = habib_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 11] = habib_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
habib_df.iloc[:, 12] = habib_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

habib_df['DOB'] = pd.to_datetime(habib_df['DOB']).dt.strftime('%m/%d/%Y')

habib_dups = pd.DataFrame()

habib_dups = habib_df[habib_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not habib_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=habib_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in habib_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            unique_records = unique_records.append(group.iloc[0], ignore_index=True)
        else:
            # If not, delete all records in the group
            habib_dups = habib_dups.drop(group.index)
    
    # Append the unique records to the original dataframe
    habib_df = pd.concat([habib_df, unique_records])
    
if not habib_dups.empty:
    # Add error message to the duplicate records
    habib_dups['Error'] = "Duplicate Medicare Number!"
    habib_dups['Source'] = '7Tel'
    print("Found duplicate values in MBI:\n", habib_dups)


habib_phone_matches = habib_df[habib_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not habib_phone_matches.empty:
    habib_df = habib_df.drop(habib_phone_matches.index)
    habib_dups = pd.concat([habib_dups, habib_phone_matches])
    habib_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC List.")

habib_mid_matches = habib_df[habib_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not habib_mid_matches.empty:
    habib_df = habib_df.drop(habib_mid_matches.index)
    habib_dups = pd.concat([habib_dups, habib_mid_matches])
    habib_dups['Error'] = "Medicare # matched with MID List"
    print("Found medicare matches in Habib and MID List.")

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
habib_order_matches = habib_df[habib_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not habib_order_matches.empty:
    habib_df = habib_df.drop(habib_order_matches.index)
    habib_dups = pd.concat([habib_dups, habib_order_matches])
    habib_dups['Error'] = "Matched with the Master MID"
    print("Found medicare matches in Habib and Master MID List.")

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(habib_df)
habib_df['Order Number'] = list(range(last_order_number, end_num))
habib_df['Source'] = "Habib"
habib_df['Order Status'] = "InProcess"
habib_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(habib_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
habib_dups.to_excel('Habib Completed.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Habib-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#












#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------CPL---------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



cpl_df.iloc[:, 3] = cpl_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 4] = cpl_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 5] = cpl_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 6] = cpl_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 7] = cpl_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 8] = cpl_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
cpl_df.iloc[:, 9] = cpl_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 10] = cpl_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 11] = cpl_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
cpl_df.iloc[:, 12] = cpl_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

cpl_df['DOB'] = pd.to_datetime(cpl_df['DOB']).dt.strftime('%m/%d/%Y')

cpl_dups = pd.DataFrame()

cpl_dups = cpl_df[cpl_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not cpl_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=cpl_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in cpl_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            unique_records = unique_records.append(group.iloc[0], ignore_index=True)
        else:
            # If not, delete all records in the group
            cpl_dups = cpl_dups.drop(group.index)
    
    # Append the unique records to the original dataframe
    cpl_df = pd.concat([cpl_df, unique_records])
    
if not cpl_dups.empty:
    # Add error message to the duplicate records
    cpl_dups['Error'] = "Duplicate Medicare Number!"
    cpl_dups['Source'] = '7Tel'
    print("Found duplicate values in MBI:\n", cpl_dups)
    
if not cpl_dups.empty:
    # Add error message to the duplicate records
    cpl_dups['Error'] = "Duplicate Medicare Number!"
    cpl_dups['Source'] = '7Tel'
    print("Found duplicate values in MBI:\n", cpl_dups)

cpl_phone_matches = cpl_df[cpl_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not cpl_phone_matches.empty:
    cpl_df = cpl_df.drop(cpl_phone_matches.index)
    cpl_dups = pd.concat([cpl_dups, cpl_phone_matches])
    cpl_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in CPL and DNC.")

cpl_mid_matches = cpl_df[cpl_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not cpl_mid_matches.empty:
    cpl_df = cpl_df.drop(cpl_mid_matches.index)
    cpl_dups = pd.concat([cpl_dups, cpl_mid_matches])
    cpl_dups['Error'] = "Medicare # matched with MID List"
    print("Found medicare matches in CPL and MID.")

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
cpl_order_matches = cpl_df[cpl_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not cpl_order_matches.empty:
    cpl_df = cpl_df.drop(cpl_order_matches.index)
    cpl_dups = pd.concat([cpl_dups, cpl_order_matches])
    cpl_dups['Error'] = "Matched with the Master MID"
    print("Found medicare matches in CPL and Master MID List.")

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(cpl_df)
cpl_df['Order Number'] = list(range(last_order_number, end_num))
cpl_df['Source'] = "CPL"
cpl_df['Order Status'] = "InProcess"
cpl_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(cpl_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
cpl_dups.to_excel('CPL Completed.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------CPL-End-----------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#











#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Mitti---------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



mitti_df.iloc[:, 3] = mitti_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 4] = mitti_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 5] = mitti_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 6] = mitti_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 7] = mitti_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 8] = mitti_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
mitti_df.iloc[:, 9] = mitti_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 10] = mitti_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 11] = mitti_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
mitti_df.iloc[:, 12] = mitti_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

mitti_df['DOB'] = pd.to_datetime(mitti_df['DOB']).dt.strftime('%m/%d/%Y')

mitti_dups = pd.DataFrame()

mitti_dups = mitti_df[mitti_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not mitti_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=mitti_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in mitti_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            unique_records = unique_records.append(group.iloc[0], ignore_index=True)
        else:
            # If not, delete all records in the group
            mitti_dups = mitti_dups.drop(group.index)
    
    # Append the unique records to the original dataframe
    mitti_df = pd.concat([mitti_df, unique_records])
    
if not mitti_dups.empty:
    # Add error message to the duplicate records
    mitti_dups['Error'] = "Duplicate Medicare Number!"
    mitti_dups['Source'] = '7Tel'
    print("Found duplicate values in MBI:\n", mitti_dups)

mitti_phone_matches = mitti_df[mitti_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not mitti_phone_matches.empty:
    mitti_df = mitti_df.drop(mitti_phone_matches.index)
    mitti_dups = pd.concat([mitti_dups, mitti_phone_matches])
    mitti_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Mitti and DNC.")

mitti_mid_matches = mitti_df[mitti_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not mitti_mid_matches.empty:
    mitti_df = mitti_df.drop(mitti_mid_matches.index)
    mitti_dups = pd.concat([mitti_dups, mitti_mid_matches])
    mitti_dups['Error'] = "Medicare # matched with MID List"
    print("Found medicare matches in Mitti and MID.")

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
mitti_order_matches = mitti_df[mitti_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not mitti_order_matches.empty:
    mitti_df = mitti_df.drop(mitti_order_matches.index)
    mitti_dups = pd.concat([mitti_dups, mitti_order_matches])
    mitti_dups['Error'] = "Matched with the Master MID"
    print("Found medicare matches in Mitti and Master MID List.")

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(mitti_df)
mitti_df['Order Number'] = list(range(last_order_number, end_num))
mitti_df['Source'] = "Mitti"
mitti_df['Order Status'] = "InProcess"
mitti_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(mitti_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
mitti_dups.to_excel('Mitti Completed.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------Mitti-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#











#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------7Tel--------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#



seventel_df.iloc[:, 3] = seventel_df.iloc[:, 3].str.replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 4] = seventel_df.iloc[:, 4].str.replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 5] = seventel_df.iloc[:, 5].str.replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 6] = seventel_df.iloc[:, 6].replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 7] = seventel_df.iloc[:, 7].str.replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 8] = seventel_df.iloc[:, 8].str.replace('[,."\'-]', '', regex=True)
seventel_df.iloc[:, 9] = seventel_df.iloc[:, 9].str.replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 10] = seventel_df.iloc[:, 10].str.replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 11] = seventel_df.iloc[:, 11].replace('[,. "\'-]', '', regex=True)
seventel_df.iloc[:, 12] = seventel_df.iloc[:, 12].replace('[,. "\'-]', '', regex=True)

seventel_df['DOB'] = pd.to_datetime(seventel_df['DOB']).dt.strftime('%m/%d/%Y')

seventel_dups = pd.DataFrame()

seventel_dups = seventel_df[seventel_df.duplicated(subset=['MedicareNumber'], keep= False)]
if not seventel_dups.empty:
    # Create an empty dataframe to store unique records
    unique_records = pd.DataFrame(columns=seventel_df.columns)
    
    # Iterate over each group of duplicates
    for _, group in seventel_dups.groupby('MedicareNumber'):
        # Check if the first and last names are the same for all records in the group
        if group['First Name (Billing)'].nunique() == 1 and group['Last Name (Billing)'].nunique() == 1:
            # If so, keep one record and delete the others
            unique_records = unique_records.append(group.iloc[0], ignore_index=True)
        else:
            # If not, delete all records in the group
            seventel_dups = seventel_dups.drop(group.index)
    
    # Append the unique records to the original dataframe
    seventel_df = pd.concat([seventel_df, unique_records])
    
if not seventel_dups.empty:
    # Add error message to the duplicate records
    seventel_dups['Error'] = "Duplicate Medicare Number!"
    seventel_dups['Source'] = '7Tel'
    print("Found duplicate values in MBI:\n", seventel_dups)

seventel_phone_matches = seventel_df[seventel_df['Phone (Billing)'].isin(dnc_df['phone'])]
if not seventel_phone_matches.empty:
    seventel_df = seventel_df.drop(seventel_phone_matches.index)
    seventel_dups = pd.concat([seventel_dups, seventel_phone_matches])
    seventel_dups['Error'] = "Phone Number matched with DNC List"
    print("Found phone matches in Habib and DNC.")

seventel_mid_matches = seventel_df[seventel_df['MedicareNumber'].isin(mid_df['MEDICARENUMBER'])]
if not seventel_mid_matches.empty:
    seventel_df = seventel_df.drop(seventel_mid_matches.index)
    seventel_dups = pd.concat([seventel_dups, seventel_mid_matches])
    seventel_dups['Error'] = "Medicare # matched with MID List"
    print("Found medicare matches in Habib and MID.")

orderbatch_df['Phone (Billing)'] = orderbatch_df['Phone (Billing)'].astype(str)
seventel_order_matches = seventel_df[seventel_df['MedicareNumber'].isin(orderbatch_df['MedicareNumber'])]
if not seventel_order_matches.empty:
    seventel_df = seventel_df.drop(seventel_order_matches.index)
    seventel_dups = pd.concat([seventel_dups, seventel_order_matches])
    seventel_dups['Error'] = "Matched with the Master MID"
    print("Found medicare matches in Habib and MID.")

last_order_number = orderbatch_df['Order Number'].max()
end_num = last_order_number + len(seventel_df)
seventel_df['Order Number'] = list(range(last_order_number, end_num))
seventel_df['Source'] = "7Tel"
seventel_df['Order Status'] = "InProcess"
seventel_df['Order Date'] = now.strftime('%m/%d/%Y')
orderbatch_df = orderbatch_df.append(seventel_df, ignore_index = True)
orderbatch_df.to_excel('OrderBatch.xlsx', index = False)
seventel_dups.to_excel('7Tel Completed.xlsx')

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------7Tel-End---------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#